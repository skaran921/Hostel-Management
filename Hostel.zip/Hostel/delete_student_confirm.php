<?php
session_start();
if(isset($_SESSION["admin_id"]))
{
}
else
{
	header("Location:index.php");
}
?>
<?php 
$student_id=$_GET["student_id"];
include 'db.php';
$sql="DELETE FROM student WHERE id='$student_id'";
$result=$conn->query($sql);
if($result==TRUE)
{
	?>
	  <script>
	    alert("Student Record Deleted!!!");
		window.close();
	  </script>
	<?php 
}
else
{
	?>
	<script>
	    alert("error!!! Student Record Not Deleted!!!");
		window.close();
	</script>
	<?php
}
?>

