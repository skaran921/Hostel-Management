<nav class="navbar navbar-expand-lg bg-dark navbar-dark fixed-top" style="">
    <a href="dashboard.php" class="navbar-brand">
	  <i class='fa fa-institution' style="color:gold;font-size:30px"></i> Hostel Management
	</a>
	<button type="butoon" class="navbar-toggler" aria-expanded="true" data-toggle="collapse" data-target="#navb">
	   <span class="navbar-toggler-icon">
	</button>
	
	<div class="navbar-collapse collapse hide" id="navb">
	    <ul class="navbar-nav mr-auto">
		 <li class="nav-item">
			   <a href="dashboard.php" class="active nav-link">Dashboard</a>
			</li>	
            <li class="nav-item dropdown">
			   <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown"><i class="fa fa-building"></i> Room's</a>
			     <div class="dropdown-menu" id="navdrop1">
				     <a href="add room.php" class="dropdown-item"><i class="fa fa-plus"></i> Add Room</a>
				     <a href="edit room.php" class="dropdown-item"><i class="fa fa-edit"></i> Edit Room</a>
				     <a href="delete room.php" class="dropdown-item"><i class="fa fa-trash"></i> Delete Room</a>
				     <a href="search room.php" class="dropdown-item"><i class="fa fa-search"></i> Search Room</a>
				 </div>
			</li>	
			
            <li class="nav-item dropdown">
			   <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> Student</a>
			        <div class="dropdown-menu" id="navdrop1">
					   <a href="add student.php" class="dropdown-item"><i class="fa fa-plus"></i> Add Student</a>
					   <a href="edit student.php" class="dropdown-item"><i class="fa fa-edit"></i> Edit Student</a>
				     <a href="delete student.php" class="dropdown-item"><i class="fa fa-trash"></i> Delete Student</a>
				     <a href="search student.php" class="dropdown-item"><i class="fa fa-search"></i> Search Student</a>
					</div>
			</li>	
		
		
			<li class="nav-item dropdown">
			   <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bed"></i> Furniture</a>
			        <div class="dropdown-menu" id="navdrop1">
					   <a href="add furniture.php" class="dropdown-item"><i class="fa fa-plus"></i> Add Room Furniture</a>
					   <a href="edit furniture.php" class="dropdown-item"><i class="fa fa-edit"></i> Edit Room Furniture</a>
				     <a href="delete furniture.php" class="dropdown-item"><i class="fa fa-trash"></i> Delete Furniture</a>
				     <a href="search furniture.php" class="dropdown-item"><i class="fa fa-search"></i> Search Furniture</a>
					</div>
			</li>	
			
			<li class="nav-item dropdown">
			   <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown"><i class="fa fa-exchange"></i> Transaction</a>
			        <div class="dropdown-menu" id="navdrop1">
					   <a href="issue room.php" class="dropdown-item"><i class="fa fa-handshake-o"></i> issue Room </a>
					   <a href="in entry.php" class="dropdown-item"><i class="fa fa-arrow-right"></i> in Entry </a>
					   <a href="out entry.php" class="dropdown-item"><i class="fa fa-arrow-left"></i> Out Entry </a>
					   <a href="delete issue room.php" class="dropdown-item"><i class="fa fa-trash"></i> Delete Issue Room</a>
					  
					   
					</div>
			</li>	
			
			<li class="nav-item dropdown">
			   <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown"><i class="fa fa-cutlery"></i> Mess</a>
			        <div class="dropdown-menu" id="navdrop1">
					   <a href="mess attendance.php" class="dropdown-item"><i class="fa fa-plus"></i> Mess Attendance</a>
					   <a href="mess attendance report.php" class="dropdown-item"><i class="fa fa-list-alt"></i> Mess Attendance Reoprt</a>					  
					   <a href="date wise attendance report.php" class="dropdown-item"><i class="fa fa-list-alt"></i> Date Wise Attendance Reoprt</a>
					   <a href="total attendance report.php" class="dropdown-item"><i class="fa fa-list-alt"></i> Total Attendance Reoprt</a>
					    <a href="mess attendance report between period.php" class="dropdown-item"><i class="fa fa-list-alt"></i> Mess Attendance Reoprt Between Period</a>
					   
					</div>
			</li>       

	          <li class="nav-item dropdown">
			   <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown"><i class="fa fa-print"></i> Print Reports</a>
			        <div class="dropdown-menu" id="navdrop1">
					   <a href="all room report.php" class="dropdown-item"><i class="fa fa-list-alt"></i> All Room Report</a>
					   <a href="room furniture report.php" class="dropdown-item"><i class="fa fa-list-alt"></i> Room Furniture Report</a>					  
					   <a href="combined report.php" class="dropdown-item"><i class="fa fa-list-alt"></i> Combined Report</a>	
                       <a href="room issue report.php" class="dropdown-item"><i class="fa fa-list-alt"></i> Room Issue Reoprt</a>	
                       <a href="room wise issue report.php" class="dropdown-item"><i class="fa fa-list-alt"></i> Room Wise Issue Report</a>	
                       <a href="student wise issue report.php" class="dropdown-item"><i class="fa fa-list-alt"></i> Student Wise issue Report </a>					   
                           <hr>					   
                       <a href="all student report.php" class="dropdown-item"><i class="fa fa-list-alt"></i> All Student Report</a>						   
					   <a href="mess id report.php" class="dropdown-item"><i class="fa fa-list-alt"></i> Mess ID Reoprt</a>							  
					             <hr>
					   <a href="guest entry report.php" class="dropdown-item"><i class="fa fa-list-alt"></i> Guest Entry Report</a>	
					             <hr>
					   <a href="free room report.php" class="dropdown-item"><i class="fa fa-list-alt"></i> Free Room Info</a>	
                    					   
					</div>
			  </li>
	    
		       	<li class="nav-item dropdown">
			   <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown"><i class="fa fa-wrench"></i> Settings</a>
			        <div class="dropdown-menu" id="navdrop1">
					   <a href="change password.php" class="dropdown-item"><i class="fa fa-key"></i> Change Password</a>	
                            <hr>					   
					   <a href="add total room.php" class="dropdown-item"><i class="fa fa-plus"></i> Add Total Room</a>					  
					   <a href="update total room.php" class="dropdown-item"><i class="fa fa-edit"></i> Update Total Room</a>	
                                       <hr>					   
					   <a href="#" class="dropdown-item"><i class="fa fa-plus"></i> Add Floor</a>					  
					   <a href="#" class="dropdown-item"><i class="fa fa-trash"></i> Delete Floor</a>	
                        <hr>					   
					   <a href="add class.php" class="dropdown-item"><i class="fa fa-plus"></i> Add Class</a>					  
					   <a href="update class.php" class="dropdown-item"><i class="fa fa-edit"></i> Update Class</a>					  
					   <a href="#" class="dropdown-item"><i class="fa fa-trash"></i> Delete Class</a>	
                            <hr>					   
						 <a href="select session.php" class="dropdown-item"><i class="fa fa-calendar-plus-o"></i> Select Session</a>
                              <hr>						 
						 <a href="select font style.php" class="dropdown-item"><i class="fa fa-font text-danger"></i> Select Font Style</a>	
						    <hr>
							
					</div>
			  </li>
		
			<li class="nav-item">
			   <a href="logout.php" class="nav-link"><i class="fa fa-sign-out"></i> Logout</a>
			</li>
		</ul>
	</div>
</nav>