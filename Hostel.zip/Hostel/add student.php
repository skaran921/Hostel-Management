<?php
session_start();
if(isset($_SESSION["admin_id"]))
{
}
else
{
	header("Location:index.php");
}

		   include 'db.php';
		   $sql="SELECT * FROM session";
		   $result=$conn->query($sql);
		   if($row=$result->fetch_assoc())
		   {
			 $_SESSION["current_session"]=$row["session"];	  
		   }	

?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
    <meta name="description" content="Hostel Management Application In Php">
    <meta name="keywords" content="skaran921,karan soni,Hostel Management">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link rel="icon" href="logo/logo.png" type="img/png"> 
    <title>Add Student - Hostel Management</title>
	 <!-------------------------Font Style ----------------------------->
	                        <?php
                               include 'db.php';							 
                               $sql="SELECT * FROM font_style WHERE id=1";
                               $result=$conn->query($sql);
                               if($row=$result->fetch_assoc())
							   {
								   ?>
								     <style>
									    body{font-family:<?php echo $row['font_style'];?>}
									 </style>
								   <?php
							   }
							?>
	 <!-------------------------Font Style ----------------------------->
  </head>
  <body>
       <?php
	       include 'header.php';
	   ?>
	   <br>
	   <br>
	   <br>
<center>
	<div class="" style="max-width:600px">
       <div class="card text-light" style="background-color:yellowgreen">
	      <div class="card-header">
		           <i class="fa fa-plus"></i> <b>Add Student </b>
		  </div>
		    <div class="card-body bg-light text-dark">
			 <div class="alert alert-danger font-weight-bold" id="error"></div>
			    <div class="alert alert-success font-weight-bold" id="msg"></div>
			     <form action="add student.php" method="post"  align="left" enctype="multipart/form-data">
				     <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b>Name:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <input type="text" name="name" id="name" class="form-control" placeholder="Student Full Name" required autofocus>
							</div>
					    </div>		
					 </div>
					 
					 <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b>Father Name:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <input type="text" name="fname" id="fname" class="form-control" placeholder="Student Father Name" required>
							</div>
					    </div>		
					 </div>
					 					  
					 <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b>DOB:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <input type="date" name="dob" id="dob" class="form-control" placeholder="Select Date OF Birth" required>
							</div>
					    </div>		
					 </div>
					 
					 					  
					 <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b> Address:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <textarea name="address" id="address" class="form-control" placeholder="Parmanent Address OF Student" required></textarea>
							</div>
					    </div>		
					 </div>
					 
					 <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b>City/Village Name:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <input type="text" name="city" id="city" class="form-control" placeholder="Student City/Village Name" required>
							</div>
					    </div>		
					 </div>
					 
					  <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b>District:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <input type="text" name="district" id="district" class="form-control" placeholder="Student District Name" required>
							</div>
					    </div>		
					 </div>
					
					 <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b>Pin-Code:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <input type="number" name="pin" id="pin" class="form-control" placeholder="Student City/Village Pin-Code" oninput="check_pin_length()" required>
							</div>
					    </div>		
					 </div>
					
					 <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b>Select Class:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <select name="class" id="class" class="form-control">
							   <option></option>	
							   <?php class_name(); ?>
							</select>
							</div>
					    </div>		
					 </div>	
					 
					 <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b>Class Roll No.:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <input type="number" name="class_roll_no" id="class_roll_no" class="form-control" placeholder="Student Class Roll No." required>
							</div>
					    </div>		
					 </div>
					 
					 <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b>Select Session:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <select name="session" id="session" class="form-control" placeholder="Student Class Roll No." required>
							  <option>
							     <?php 
								    if(isset($_SESSION["current_session"]))
									{
										echo $_SESSION["current_session"];
									}
								 ?>
							  </option>
							  
							  </select>
							</div>
					    </div>		
					 </div>
					 
					 <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b>Student Mobile Number:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <input type="number" name="student_mobile_no" id="student_mobile_no" class="form-control" oninput="check_s_mobile_length()" placeholder="Student Mobile Number" required>
							</div>
					    </div>		
					 </div>
					 
					 <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b>Parents/Guardian Mobile Number:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <input type="number" name="parent_mobile_no" id="parent_mobile_no" class="form-control" oninput="check_p_mobile_length()" placeholder="Student Parents/Guardian Mobile Number" required>
							</div>
					    </div>		
					 </div>
					 
					  
					 <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b>Student Image:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <input type="file" name="image" id="image" class="form-control" accept="image/*" placeholder="Select Student Image" required>
							</div>
					    </div>		
					 </div>
					 
					  <div class="form-group"> 
					    
						  <center>	 <button type="submit" name="add" class="btn btn-primary" onclick="validate()" title="Click Here For Save Data"><i class="fa fa-save"></i> Add Student</button></center>
					 </div>
                 </form>				 
			</div>
	   </div>
	</div>
</center>	
  
	   <?php
	       include 'footer.php';
	   ?>
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="alertify/js/alertify.js"></script>
	<!-- Add icon library -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </body>
</html>
<script>
document.getElementById("error").style.display="none";
document.getElementById("msg").style.display="none";
   function validate()
   {
	   var name=document.getElementById('name').value;
	   var fname=document.getElementById('fname').value;
	   var dob=document.getElementById('dob').value;
	   var address=document.getElementById('address').value;
	   var city=document.getElementById('city').value;
	   var district=document.getElementById('district').value;
	   var pin=document.getElementById('pin').value;
	   var classs=document.getElementById('class').value;
	   var roll=document.getElementById('district').value;
	   var session=document.getElementById('session').value;
	   var student_mobile_no=document.getElementById('student_mobile_no').value;
	   var parent_mobile_no=document.getElementById('parent_mobile_no').value;
	   var image=document.getElementById('image').value;
	   
	    var msg1="<i class='fa fa-warning'></i> Please Enter Student Name";
	    var msg2="<i class='fa fa-warning'></i> Please Enter Student Father Name";
	    var msg3="<i class='fa fa-warning'></i> Please Enter Student DOB";
	    var msg4="<i class='fa fa-warning'></i> Please Enter Student Parmanent Address";
	    var msg5="<i class='fa fa-warning'></i> Please Enter Student City/Village Name";
	    var msg6="<i class='fa fa-warning'></i> Please Enter Student District Name";
	    var msg7="<i class='fa fa-warning'></i> Please Enter Pin-Code";
	    var msg8="<i class='fa fa-warning'></i> Please Select Class";
	    var msg9="<i class='fa fa-warning'></i> Please Enter Class Roll No.";
	    var msg10="<i class='fa fa-warning'></i> Please Select Session";
	    var msg11="<i class='fa fa-warning'></i> Please Enter Student Mobile Number";
	    var msg12="<i class='fa fa-warning'></i> Please Enter Student Parents/Guardian Mobile Number";
	    var msg13="<i class='fa fa-warning'></i> Please Select Student Image";
	   
	   if(name=="")
	   {
		  alertify.log(msg1);   
		  document.getElementById("error").innerHTML=msg1;
		  document.getElementById("error").style.display="block";
	   }
	   else if(fname=="")
	   {
		   alertify.log(msg2);
		   document.getElementById("error").innerHTML=msg2;
		  document.getElementById("error").style.display="block";
	   }
	   else if(dob=="")
	   {
		   alertify.log(msg3);
		   document.getElementById("error").innerHTML=msg3;
		  document.getElementById("error").style.display="block";
	   }
	   else if(address=="")
	   {
		   alertify.log(msg4);
		   document.getElementById("error").innerHTML=msg4;
		  document.getElementById("error").style.display="block";
	   }
	   else if(city=="")
	   {
		   alertify.log(msg5);
		   document.getElementById("error").innerHTML=msg5;
		  document.getElementById("error").style.display="block";
	   }
	   else if(district=="")
	   {
		   alertify.log(msg6);
		   document.getElementById("error").innerHTML=msg6;
		  document.getElementById("error").style.display="block";
	   }
	   else if(pin=="")
	   {
		   alertify.log(msg7);
		   document.getElementById("error").innerHTML=msg7;
		  document.getElementById("error").style.display="block";
	   }
	   else if(classs=="")
	   {
		   alertify.log(msg8);
		   document.getElementById("error").innerHTML=msg8;
		  document.getElementById("error").style.display="block";
	   }
	   else if(roll=="")
	   {
		    alertify.log(msg9);
		   document.getElementById("error").innerHTML=msg9;
		  document.getElementById("error").style.display="block";
	   }
	   
	   else if(session=="")
	   {
		   alertify.log(msg10);
		   document.getElementById("error").innerHTML=msg10;
		  document.getElementById("error").style.display="block";
	   }
	   else if(student_mobile_no=="")
	   {
		   alertify.log(msg11);
		   document.getElementById("error").innerHTML=msg11;
		  document.getElementById("error").style.display="block";
	   }
	   else if(parent_mobile_no=="")
	   {
		   alertify.log(msg12);
		   document.getElementById("error").innerHTML=msg12;
		  document.getElementById("error").style.display="block";
	   }
	   else if(image=="")
	   {
		   alertify.log(msg13);
		   document.getElementById("error").innerHTML=msg13;
		  document.getElementById("error").style.display="block";
	   }
   }
</script>

<?php
	    if(isset($_POST["add"]))
		{
			$name=$_POST["name"];
			$fname=$_POST["fname"];
			$dob=$_POST["dob"];
			$address=$_POST["address"];
			$city=$_POST["city"];
			$district=$_POST["district"];
			$pin=$_POST["pin"];
			$class=$_POST["class"];
			$class_roll_no=$_POST["class_roll_no"];
			$session=$_POST["session"];
			$student_mobile_no=$_POST["student_mobile_no"];
			$parent_mobile_no=$_POST["parent_mobile_no"];
			$image=$_FILES["image"]["name"];
			$image_name=$name.$fname.$dob.$session.$image;
			$admin_id=$_SESSION["admin_id"];
			include "db.php";
			$sql1="SELECT * FROM student WHERE name='$name' AND fname='$fname' AND dob='$dob' AND session='$session'";
			$result1=$conn->query($sql1);
			if($row=$result1->fetch_assoc())
			{
				?>
				  <script>
                     document.getElementById("error").innerHTML="<i class='fa fa-warning'></i> Student Record Already Exist";
					 alertify.alert("<b class='alert alert-danger'>Student Record Already Exist!!!</b>");
					 document.getElementById("error").style.display="block";
				  </script>
				<?php 
			}
			else
			{
				if(is_dir("students/images/".$session."/".$class))
				{
					#directory Already Exists 
				}
				else
				{
					mkdir("students/images/".$session."/".$class,0777,true);
				}
				
		
				
			  if(move_uploaded_file($_FILES["image"]["tmp_name"],"students/images/".$session."/".$class."/".$image_name))
			  {
				  $mess_id=get_mess_id();
				  $mess_id=$mess_id+1;
                 $sql2="INSERT INTO student(name,fname,dob,address,city,district,pin,class,class_roll_no,session,student_mobile_no,parent_mobile_no,image,admin,mess_id)
		      VALUES('$name','$fname','$dob','$address','$city','$district','$pin','$class','$class_roll_no','$session','$student_mobile_no','$parent_mobile_no','$image','$admin_id','$mess_id')";
                 $result2=$conn->query($sql2);
                 if($result2==TRUE)
 				 {
                            ?>
							  <script>
							    document.getElementById("msg").innerHTML="Student Record Added!!!";
			alertify.alert("<div class='card text-success font-weight-bold'><center><i class='fa fa-check-circle' style='font-size:50px;'></i></center>Student Record Added!!!<br>Student Mess ID is:<span class='text-success'> <?php echo $mess_id;?></span></div>");
			alertify.log("<div class='card text-success font-weight-bold'><center><i class='fa fa-check-circle' style='font-size:50px;'></i></center>Student Record Added!!!<br>Student Mess ID is:<span class='text-success'> <?php echo $mess_id;?></span></div>");
					            document.getElementById("msg").style.display="block";										
							  </script>
                            <?php							
				 }	
                 else
				 {
					 ?>
					 <script>
					    document.getElementById("error").innerHTML="error!!! Record Not Added!!!";
						alertify.alert("<b class='alert alert-danger'>error!!! Record Not Added!!!</b>");
					    document.getElementById("error").style.display="block";
					 </script>
					 <?php
				 }					 
			  }
              else
			  {
				  ?>
					 <script>
					    document.getElementById("error").innerHTML="error!!! Images Not Uploaded!!!";
						alertify.alert("<b class='alert alert-danger'>error!!! Images Not Uploaded!!!</b>");
					    document.getElementById("error").style.display="block";
					 </script>
					 <?php
			  }				  
			}
		}
	 ?>

	 <script>
	    function check_pin_length()
		{
			var pin=document.getElementById("pin").value;
			if(pin.length>6)
			{
				document.getElementById("pin").value=document.getElementById("pin").value.slice(0,6);
			}
		}
		
		function check_s_mobile_length()
		{
			var student_mobile=document.getElementById("student_mobile_no").value;
			if(student_mobile.length>10)
			{
				document.getElementById("student_mobile_no").value=document.getElementById("student_mobile_no").value.slice(0,10);
			}
		}
		
		function check_p_mobile_length()
		{
			var parent_mobile=document.getElementById("parent_mobile_no").value;
			if(parent_mobile.length>10)
			{
				document.getElementById("parent_mobile_no").value=document.getElementById("parent_mobile_no").value.slice(0,10);
			}
		}
	 </script>
	 
	 <?php
	    function class_name()
		{
			include 'db.php';
			$sql="SELECT name,year FROM class ORDER BY name";
			$result=$conn->query($sql);
			while($row=$result->fetch_assoc())
            {
				?>
				  <option><?php echo $row['name']." ".$row['year'];?></option>
				<?php
			}
		}
		
		function get_mess_id()
		{
			include 'db.php';
			$current_session=$_SESSION["current_session"];
			$sql="SELECT mess_id FROM student WHERE session='$current_session' ORDER BY mess_id DESC";
			$result=$conn->query($sql);
			if($row=$result->fetch_assoc())
            {
				return $row['mess_id'];
			}
			else
			{
				return 0;
			}
		}
	 ?>