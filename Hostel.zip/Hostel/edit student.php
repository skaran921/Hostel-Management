<?php
session_start();
if(isset($_SESSION["admin_id"]))
{
}
else
{
	header("Location:index.php");
}


           include 'db.php';
		   $sql="SELECT * FROM session";
		   $result=$conn->query($sql);
		   if($row=$result->fetch_assoc())
		   {
			 $_SESSION["current_session"]=$row["session"];	  
		   }	

?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags --> 
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
    <meta name="description" content="Hostel Management Application In Php">
    <meta name="keywords" content="skaran921,karan soni,Hostel Management">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link rel="icon" href="logo/logo.png" type="img/png"> 
    <title>edit student - Hostel Management</title>
	    <!-------------------------Font Style ----------------------------->
	                        <?php
                               include 'db.php';							 
                               $sql="SELECT * FROM font_style WHERE id=1";
                               $result=$conn->query($sql);
                               if($row=$result->fetch_assoc())
							   {
								   ?>
								     <style>
									    body{font-family:<?php echo $row['font_style'];?>}
									 </style>
								   <?php
							   }
							?>
	 <!-------------------------Font Style ----------------------------->
  </head>
  <body>
       <?php
	       include 'header.php';
	   ?>
	   <br>
	   <br>
	   <br>
       <div class="container" style="max-width:400px">
	        <div class="card">
			    <div class="card-header">   
				    <b> <i class="fa fa-edit"></i> Edit Student Info</b> 
				</div>
			   <div class="card-body">
			        <div class="alert alert-danger font-weight-bold" id="error"></div>
					<div class="alert alert-success font-weight-bold" id="error1"></div>
			       <form action="edit student.php" method="post">
				            <div class="form-group">
							   <label class="form-check-label"><b>Mess ID:<i class="fa fa-asterisk text-danger"></i></b></label>
							   <input type="search" name="mess_id" id="mess_id" placeholder="Enter Mess ID" class="form-control" required autofocus><br>
							     <button type="submit" name="go" class="btn btn-info" onclick="validate1()"> <i class="fa fa-search"></i> Go</button>
							</div>
				   </form>
			   </div>
			</div>
	   </div>
	   
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="alertify/js/alertify.js"></script>
	<!-- Add icon library -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </body>
</html>

<script>
document.getElementById("error").style.display="none";
document.getElementById("error1").style.display="none";
 function validate1()
 {
	 var mess_id=document.getElementById("mess_id").value;
	 var msg1="<i class='fa fa-warning'></i> Please Enter Mess ID";
	 if(mess_id=="")
	 {
		 alertify.log(msg1);
		 document.getElementById("error").innerHTML=msg1;
		 document.getElementById("error").style.display="block"
	 }
 }
</script>

<?php 
if(isset($_POST["go"]))
{
	 $mess_id=$_POST["mess_id"];
	 $current_session=$_SESSION["current_session"];
	 include 'db.php';
	 $sql="SELECT * FROM student WHERE mess_id='$mess_id' AND session='$current_session'";
	 $result=$conn->query($sql);
	 if($row=$result->fetch_assoc())
	 {		 
		  ?>
		  
		               <center>
	<div class="container" style="max-width:600px">
       <div class="card text-light" style="background-color:red">
	      <div class="card-header">
		           <i class="fa fa-edit"></i> <b>Update Student Info</b>
		  </div>
		    <div class="card-body bg-light text-dark">		
			     <form action="edit student.php" method="post"  align="left" enctype="multipart/form-data">
				    <input type="hidden" name="student_record_id" value="<?php echo $row['id'];?>" required>
				     <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b>Name:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <input type="text" name="name" id="name" class="form-control" value="<?php echo $row['name'];?>" placeholder="Student Full Name" required autofocus>
							</div>
					    </div>		
					 </div>
					 
					 <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b>Father Name:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <input type="text" name="fname" id="fname" class="form-control"  value="<?php echo $row['fname'];?>" placeholder="Student Father Name" required>
							</div>
					    </div>		
					 </div>
					 					  
					 <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b>DOB:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <input type="date" name="dob" id="dob" class="form-control"  value="<?php echo $row['dob'];?>" placeholder="Select Date OF Birth" required>
							</div>
					    </div>		
					 </div>
					 
					 					  
					 <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b> Address:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <textarea name="address" id="address" class="form-control" placeholder="Parmanent Address OF Student" required> <?php echo $row['address'];?></textarea>
							</div>
					    </div>		
					 </div>
					 
					 <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b>City/Village Name:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <input type="text" name="city" id="city" class="form-control"  value="<?php echo $row['city'];?>" placeholder="Student City/Village Name" required>
							</div>
					    </div>		
					 </div>
					 
					  <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b>District:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <input type="text" name="district" id="district" class="form-control"  value="<?php echo $row['district'];?>" placeholder="Student District Name" required>
							</div>
					    </div>		
					 </div>
					
					 <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b>Pin-Code:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <input type="number" name="pin" id="pin" class="form-control"  value="<?php echo $row['pin'];?>" placeholder="Student City/Village Pin-Code" oninput="check_pin_length()" required>
							</div>
					    </div>		
					 </div>
					
					 <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b>Select Class:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <select name="class" id="class" class="form-control">
							   <option><?php echo $row['class'];?></option>	
							   <?php class_name(); ?>
							</select>
							</div>
					    </div>		
					 </div>	
					 
					 <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b>Class Roll No.:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <input type="number" name="class_roll_no" id="class_roll_no" class="form-control"  value="<?php echo $row['class_roll_no'];?>" placeholder="Student Class Roll No." required>
							</div>
					    </div>		
					 </div>
					 
					 <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b>Select Session:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <select name="session" id="session" class="form-control" placeholder="Student Class Roll No." required>
							<option> <?php echo $row['session'];?></option>
							  <option>
							     <?php 
								    if(isset($_SESSION["current_session"]))
									{
										echo $_SESSION["current_session"];
									}
								 ?>
							  </option>
							  
							  </select>
							</div>
					    </div>		
					 </div>
					 
					 <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b>Student Mobile Number:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <input type="number" name="student_mobile_no" id="student_mobile_no" class="form-control" oninput="check_s_mobile_length()"  value="<?php echo $row['student_mobile_no'];?>" placeholder="Student Mobile Number" required>
							</div>
					    </div>		
					 </div>
					 
					 <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b>Parents/Guardian Mobile Number:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <input type="number" name="parent_mobile_no" id="parent_mobile_no" class="form-control" oninput="check_p_mobile_length()"  value="<?php echo $row['parent_mobile_no'];?>" placeholder="Student Parents/Guardian Mobile Number" required>
							</div>
					    </div>		
					 </div>	

					  <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b>Student Image:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 	                                    					
						    <input type="file" name="image" id="image" class="form-control" accept="image/*" placeholder="Select Student Image" required>
							</div>
					    </div>		
					 </div>
                     					 
					  <div class="form-group"> 
					    
						  <center>	 <button type="submit" name="update" class="btn btn-primary" onclick="validate()" title="Click Here For Save Data"><i class="fa fa-save"></i> Update Student</button></center>
					 </div>
                 </form>				 
			</div>
	   </div>
	</div>
</center>

             <script>
   function validate()
   {
	   var name=document.getElementById('name').value;
	   var fname=document.getElementById('fname').value;
	   var dob=document.getElementById('dob').value;
	   var address=document.getElementById('address').value;
	   var city=document.getElementById('city').value;
	   var district=document.getElementById('district').value;
	   var pin=document.getElementById('pin').value;
	   var classs=document.getElementById('class').value;
	   var roll=document.getElementById('district').value;
	   var session=document.getElementById('session').value;
	   var student_mobile_no=document.getElementById('student_mobile_no').value;
	   var parent_mobile_no=document.getElementById('parent_mobile_no').value;
	  
	   
	    var msg1="<i class='fa fa-warning'></i> Please Enter Student Name";
	    var msg2="<i class='fa fa-warning'></i> Please Enter Student Father Name";
	    var msg3="<i class='fa fa-warning'></i> Please Enter Student DOB";
	    var msg4="<i class='fa fa-warning'></i> Please Enter Student Parmanent Address";
	    var msg5="<i class='fa fa-warning'></i> Please Enter Student City/Village Name";
	    var msg6="<i class='fa fa-warning'></i> Please Enter Student District Name";
	    var msg7="<i class='fa fa-warning'></i> Please Enter Pin-Code";
	    var msg8="<i class='fa fa-warning'></i> Please Select Class";
	    var msg9="<i class='fa fa-warning'></i> Please Enter Class Roll No.";
	    var msg10="<i class='fa fa-warning'></i> Please Select Session";
	    var msg11="<i class='fa fa-warning'></i> Please Enter Student Mobile Number";
	    var msg12="<i class='fa fa-warning'></i> Please Enter Student Parents/Guardian Mobile Number";
	   
	   
	   if(name=="")
	   {
		  alertify.log(msg1);   
		  document.getElementById("error").innerHTML=msg1;
		  document.getElementById("error").style.display="block";
	   }
	   else if(fname=="")
	   {
		   alertify.log(msg2);
		   document.getElementById("error").innerHTML=msg2;
		  document.getElementById("error").style.display="block";
	   }
	   else if(dob=="")
	   {
		   alertify.log(msg3);
		   document.getElementById("error").innerHTML=msg3;
		  document.getElementById("error").style.display="block";
	   }
	   else if(address=="")
	   {
		   alertify.log(msg4);
		   document.getElementById("error").innerHTML=msg4;
		  document.getElementById("error").style.display="block";
	   }
	   else if(city=="")
	   {
		   alertify.log(msg5);
		   document.getElementById("error").innerHTML=msg5;
		  document.getElementById("error").style.display="block";
	   }
	   else if(district=="")
	   {
		   alertify.log(msg6);
		   document.getElementById("error").innerHTML=msg6;
		  document.getElementById("error").style.display="block";
	   }
	   else if(pin=="")
	   {
		   alertify.log(msg7);
		   document.getElementById("error").innerHTML=msg7;
		  document.getElementById("error").style.display="block";
	   }
	   else if(classs=="")
	   {
		   alertify.log(msg8);
		   document.getElementById("error").innerHTML=msg8;
		  document.getElementById("error").style.display="block";
	   }
	   else if(roll=="")
	   {
		    alertify.log(msg9);
		   document.getElementById("error").innerHTML=msg9;
		  document.getElementById("error").style.display="block";
	   }
	   
	   else if(session=="")
	   {
		   alertify.log(msg10);
		   document.getElementById("error").innerHTML=msg10;
		  document.getElementById("error").style.display="block";
	   }
	   else if(student_mobile_no=="")
	   {
		   alertify.log(msg11);
		   document.getElementById("error").innerHTML=msg11;
		  document.getElementById("error").style.display="block";
	   }
	   else if(parent_mobile_no=="")
	   {
		   alertify.log(msg12);
		   document.getElementById("error").innerHTML=msg12;
		  document.getElementById("error").style.display="block";
	   }
	   
   }
</script>	
		  
		 <?php		 
	 }
	 else
	 {
		 ?>
		 <script>
		     alertify.log("<i class='fa fa-warning'></i> Sorry Record Not Found!!!");
			 document.getElementById("error").innerHTML="<i class='fa fa-warning'></i> Sorry Record Not Found!!!";
			 document.getElementById("error").style.display="block";
	     </script>
		 <?php
	 }
}
?>

<?php
	       include 'footer.php';
?>


<?php
if(isset($_POST["update"]))
{
			$name=$_POST["name"];
			$fname=$_POST["fname"];
			$dob=$_POST["dob"];
			$address=$_POST["address"];
			$city=$_POST["city"];
			$district=$_POST["district"];
			$pin=$_POST["pin"];
			$class=$_POST["class"];
			$class_roll_no=$_POST["class_roll_no"];
			$session=$_POST["session"];
			$student_mobile_no=$_POST["student_mobile_no"];
			$parent_mobile_no=$_POST["parent_mobile_no"];
            $image=$_FILES["image"]["name"];
			$image_name=$name.$fname.$dob.$session.$image;			
			$admin_id=$_SESSION["admin_id"];
			$student_record_id=$_POST["student_record_id"];
			
			if(is_dir("students/images/".$session."/".$class))
				{
					#directory Already Exists 
				}
				else
				{
					mkdir("students/images/".$session."/".$class,0777,true);
				}
				
   if(move_uploaded_file($_FILES["image"]["tmp_name"],"students/images/".$session."/".$class."/".$image_name))
   {		
			include "db.php";								  
            $sql="UPDATE student SET name='$name',fname='$fname',dob='$dob',address='$address',city='$city',district='$district',pin='$pin',class='$class',
		 class_roll_no='$class_roll_no',session='$session',student_mobile_no='$student_mobile_no',parent_mobile_no='$parent_mobile_no',image='$image',admin='$admin_id' WHERE id='$student_record_id' ";		      
                 $result=$conn->query($sql);
                 if($result==TRUE)
 				 {
                            ?>
							  <script>
							    document.getElementById("error1").innerHTML="Student Record Updated!!!";
								alertify.alert("<b class='alert alert-success'>Student Record Updated!!!</b>");
					            document.getElementById("error1").style.display="block";										
							  </script>
                            <?php							
				 }	
                 else
				 {
					 ?>
					 <script>
					    document.getElementById("error").innerHTML="error!!! Record Not Update!!!";
						alertify.alert("<b class='alert alert-danger'>error!!! Record Not Updated!!!</b>");
					    document.getElementById("error").style.display="block";
					 </script>
					 <?php
				 }	           
	}
	else
	{
				  ?>
					 <script>
					    document.getElementById("error").innerHTML="error!!! Images Not Uploaded!!!";
						alertify.alert("<b class='alert alert-danger'>error!!! Images Not Uploaded!!!</b>");
					    document.getElementById("error").style.display="block";
					 </script>
					 <?php
	}		
}	
	 ?>
	 
	 
	  <?php
	    function class_name()
		{
			include 'db.php';
			$sql="SELECT name,year FROM class ORDER BY name";
			$result=$conn->query($sql);
			while($row=$result->fetch_assoc())
            {
				?>
				  <option><?php echo $row['name']." ".$row['year'];?></option>
				<?php
			}
		}
		?>