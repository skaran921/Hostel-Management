<?php
session_start();
if(isset($_SESSION["admin_id"]))
{
}
else
{
	header("Location:index.php");
}

           include 'db.php';
		   $sql="SELECT * FROM session";
		   $result=$conn->query($sql);
		   if($row=$result->fetch_assoc())
		   {
			 $_SESSION["current_session"]=$row["session"];	  
		   }	

?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
    <meta name="description" content="Hostel Management Application In Php">
    <meta name="keywords" content="skaran921,karan soni,Hostel Management">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link rel="icon" href="logo/logo.png" type="img/png"> 
    <title>Delete Student - Hostel Management</title>
	    <!-------------------------Font Style ----------------------------->
	                        <?php
                               include 'db.php';							 
                               $sql="SELECT * FROM font_style WHERE id=1";
                               $result=$conn->query($sql);
                               if($row=$result->fetch_assoc())
							   {
								   ?>
								     <style>
									    body{font-family:<?php echo $row['font_style'];?>}
									 </style>
								   <?php
							   }
							?>
	 <!-------------------------Font Style ----------------------------->
  </head>
  <body>
       <?php
	       include 'header.php';
	   ?>
	   <br>
	   <br>
	   <br>
	<div class="container">
	      <div class="table-responsive">
		      <table class="table table-striped table-hover table-border">
			     <tr class="thead-dark">
				     <th>Sr.No.</th>
				     <th>ID</th>
				     <th>Name</th>
				     <th>Father Name</th>
				     <th>DOB</th>
				     <th>Class</th>
				     <th>Session</th>
				     <th>Image</th>
				     <th>Added By</th>
				     <th></th>
			     </tr>
				 <?php room_detail();?>
			  </table>
		  </div>
	</div>
	   <?php 
	     include 'footer.php';
	   ?>
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="alertify/js/alertify.js"></script>
	<!-- Add icon library -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </body>
</html>
<?php
   function room_detail()
   {
	   $sr=1;
	   include 'db.php';
	   $current_session=$_SESSION["current_session"];
	   $sql="SELECT * FROM student WHERE session='$current_session' ORDER BY mess_id";
	   $result=$conn->query($sql);
	   while($row=$result->fetch_assoc())
	   {
		   ?>
		   <tr>
		      <td class="bg-dark text-light font-weight-bold"><?php echo $sr;?></td>
		      <td class="bg-info text-light font-weight-bold"><?php echo $row["id"];?></td>
		      <td class=" font-weight-bold"><?php echo $row["name"];?></td>
		      <td class=" font-weight-bold"><?php echo $row["fname"];?></td>
		      <td class=" font-weight-bold"><?php echo date("d-m-Y",strtotime($row["dob"]));?></td>
		      <td class=" font-weight-bold"><?php echo $row["class"];?></td>
		      <td class=" font-weight-bold"><?php echo $row["session"];?></td>
		      <td class=" font-weight-bold">
			  <img src="students/images/<?php echo $row['session']."/".$row['class']."/".$row['name'].$row['fname'].$row['dob'].$row['session'].$row['image']; ?>" style="max-width:60px;max-height:60px;" class="rounded-circle img-fluid card">
			  </td>
		      <td class="alert alert-danger font-weight-bold"><?php echo admin_name($row["admin"]);?></td>
		      <td>
			  <form action="delete student.php" method="post">
			      <input type="hidden" id="furniture_id" value="<?php echo $row['id'];?>">
				  <button type="submit" name="delete" class="btn btn-danger" onclick="confirm_delete(<?php echo $row['id'];?>)"><i class="fa fa-trash"></i> Delete</button>
			  </form>
			  </td>
		   </tr>
		   <?php
		   $sr++;
	   }
   } 

  function admin_name($admin_id)
  {
	  include 'db.php';
	  $sql="SELECT name FROM admin Where id='$admin_id'";
	  $result=$conn->query($sql);
	  if($row=$result->fetch_assoc())
	  {
		  return $row['name'];	  
	  }
  }	  
?>

<script>
  function confirm_delete(x)
  {
	  var student_id=x;
	  var answer=confirm("do you really want to delete this Student Record?");
	  if(answer)
	  {
		     window.open("delete_student_confirm.php?student_id="+student_id,"_blank");
	  }
	  else
	  {
	  }
  }
</script>