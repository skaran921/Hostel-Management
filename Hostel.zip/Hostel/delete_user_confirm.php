<?php
session_start();
if(isset($_SESSION["admin_id"]) && isset($_SESSION["super_user_id"]))
{
}
else
{
	header("Location:dashboard.php");
}
?>
<?php 
$user_id=$_GET["user_id"];
include 'db.php';
$sql="DELETE FROM admin WHERE id='$user_id'";
$result=$conn->query($sql);
if($result==TRUE)
{
	?>
	  <script>
	    alert("User Account Deleted!!!");
		window.close();
	  </script>
	<?php 
}
else
{
	?>
	<script>
	    alert("error!!! User Account Not Deleted!!!");
		window.close();
	</script>
	<?php
}
?>

