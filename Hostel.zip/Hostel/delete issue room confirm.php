<?php
session_start();
if(isset($_SESSION["admin_id"]))
{
}
else
{
	header("Location:index.php");
}
?>
<?php 
$issue_room_id=$_GET["issue_room_id"];
include 'db.php';
$sql="DELETE FROM issue_room WHERE id='$issue_room_id'";
$result=$conn->query($sql);
if($result==TRUE)
{
	?>
	  <script>
	    alert("Issue Room Deleted!!!");
		window.close();
	  </script>
	<?php 
}
else
{
	?>
	<script>
	    alert("error!!! Issue Room Not Deleted!!!");
		window.close();
	</script>
	<?php
}
?>

