<?php
session_start();
if(isset($_SESSION["admin_id"]))
{
}
else
{
	header("Location:index.php");
}
?>
<?php 
$room_id=$_GET["room_id"];
include 'db.php';
$sql="DELETE FROM room WHERE id='$room_id'";
$result=$conn->query($sql);
if($result==TRUE)
{
	?>
	  <script>
	    alert("Room Deleted!!!");
		window.close();
	  </script>
	<?php 
}
else
{
	?>
	<script>
	    alert("error!!! Room Not Deleted!!!");
		window.close();
	</script>
	<?php
}
?>

