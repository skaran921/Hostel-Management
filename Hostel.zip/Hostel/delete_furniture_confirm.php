<?php
session_start();
if(isset($_SESSION["admin_id"]))
{
}
else
{
	header("Location:index.php");
}
?>
<?php 
$furniture_id=$_GET["furniture_id"];
include 'db.php';
$sql="DELETE FROM furniture WHERE id='$furniture_id'";
$result=$conn->query($sql);
if($result==TRUE)
{
	?>
	  <script>
	    alert("Room Furniture Deleted!!!");
		window.close();
	  </script>
	<?php 
}
else
{
	?>
	<script>
	    alert("error!!! Room Furniture Not Deleted!!!");
		window.close();
	</script>
	<?php
}
?>

