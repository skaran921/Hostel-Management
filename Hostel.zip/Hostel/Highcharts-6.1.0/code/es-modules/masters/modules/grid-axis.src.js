/**
 * @license @product.name@ JS v@product.version@ (@product.date@)
 * GridAxis
 *
 * (c) 2016 Lars A. V. Cabrera
 *
 * --- WORK IN PROGRESS ---
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../parts-gantt/grid-axis.js';
