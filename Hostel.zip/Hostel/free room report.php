<?php
session_start();
if(isset($_SESSION["admin_id"]))
{
}
else
{
	header("Location:index.php");
}
include 'db.php';
		   $sql="SELECT * FROM session";
		   $result=$conn->query($sql);
		   if($row=$result->fetch_assoc())
		   {
			 $_SESSION["current_session"]=$row["session"];	  
		   }	
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
    <meta name="description" content="Hostel Management Application In Php">
    <meta name="keywords" content="skaran921,karan soni,Hostel Management">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link rel="icon" href="logo/logo.png" type="img/png"> 	
    <title>Free Room Report - Hostel Management</title>
	
	                        <?php
                               include 'db.php';							 
                               $sql="SELECT * FROM font_style WHERE id=1";
                               $result=$conn->query($sql);
                               if($row=$result->fetch_assoc())
							   {
								   ?>
								     <style>
									    body{font-family:<?php echo $row['font_style'];?>}
									 </style>
								   <?php
							   }
							?>

	  </head>
  <body> 
       <?php
	       include 'header.php';
	   ?> 
	   <br>
	   <br>
	   <br>
	      <div class="container">
		      <div class="card">
			      <div class="card-header">
				      <b><i class="fa fa-info-circle text-info"></i> Free Room Info</b> <button type="button" onclick="window.print();" class="btn card"><i class="fa fa-print"></i></button>
				  </div>
				  <div class="card-body">
				        <table class="table table-striped text-center">
						    <tr class="thead" style="background-color:yellow;">
							    <th>Sr. No.</th>
							    <th>Room No.</th>
							    <th>Floor</th>
							    <th>Room Type</th>
							    <th>Status</th>
							</tr>
							<tbody id="myTable">
							</tbody>
							<?php free_room_info();?>
						</table>
				     </div>		
				  </div>
				  <div class="card-footer">
				  </div>
			  </div>
		  </div>
	    
<?php
	   include 'footer.php';
 ?>
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="alertify/js/alertify.js"></script>
	<!-- Add icon library -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </body>
</html>


<?php 
  function free_room_info()
  {
	  include 'db.php';
	  $current_session=$_SESSION["current_session"];
	  $sql1="SELECT * FROM room ORDER BY room_no";
	  $sr=1;
	  $result1=$conn->query($sql1);
	  while($row1=$result1->fetch_assoc())
	  {
		  $room_id=$row1["id"];
		  $sql2="SELECT count(*) AS total FROM issue_room WHERE session='$current_session' AND room_id='$room_id' ORDER BY room_id";
		  ?>
		  <tr>
		     <td><?php echo $sr; ?></td>
		     <td><?php echo $row1["room_no"]; ?></td>
		     <td><?php echo $row1["floor"]; ?></td>
		     <td><?php echo $row1["room_type"]; ?></td>
			  <?php
                $result2=$conn->query($sql2);
                 if($row2=$result2->fetch_assoc())
				 {					 
					 if($row2["total"]==0)
					 {
						 if($row1["room_type"]=="Single")
						 {
						   ?>
						    <td>
							   <i class="fa fa-check-circle text-success" style="font-size:28px;"></i>
							</td>
						   <?php
						 }
						 else if($row1["room_type"]=="Two Seater")
						 {
						   ?>
						    <td>
							    <i class="fa fa-check-circle text-success" style="font-size:28px;"></i>&nbsp;
							    <i class="fa fa-check-circle text-success" style="font-size:28px;"></i>&nbsp;
							</td>
						   <?php
						 }
						  else if($row1["room_type"]=="Three Seater")
						 {
						   ?>
						    <td>
							    <i class="fa fa-check-circle text-success" style="font-size:28px;"></i>&nbsp;
							    <i class="fa fa-check-circle text-success" style="font-size:28px;"></i>&nbsp;
							    <i class="fa fa-check-circle text-success" style="font-size:28px;"></i>&nbsp;
							</td>
						   <?php
						 }
					 }		
                     
                     if($row2["total"]==1)
					 {
						 if($row1["room_type"]=="Single")
						 {
						   ?>
						    <td>
							   <i class="fa fa-times-circle text-danger" style="font-size:28px;"></i>&nbsp;
							</td>
						   <?php
						 }
						 else if($row1["room_type"]=="Two Seater")
						 {
						   ?>
						    <td>
							    <i class="fa fa-times-circle text-danger" style="font-size:28px;"></i>&nbsp;
							    <i class="fa fa-check-circle text-success" style="font-size:28px;"></i>&nbsp;							 
							</td>
						   <?php
						 }
						  else if($row1["room_type"]=="Three Seater")
						 {
						   ?>
						    <td>
							   <i class="fa fa-times-circle text-danger" style="font-size:28px;"></i>&nbsp;
							   <i class="fa fa-check-circle text-success" style="font-size:28px;"></i>&nbsp;
							   <i class="fa fa-check-circle text-success" style="font-size:28px;"></i>&nbsp;					   
							</td>
						   <?php
						 }
					 }			

                     if($row2["total"]==2)
					 {
						 if($row1["room_type"]=="Single")
						 {
						   ?>
						    <td>
							  <i class="fa fa-times-circle text-danger" style="font-size:28px;"></i>&nbsp;
							</td>
						   <?php
						 }
						 else if($row1["room_type"]=="Two Seater")
						 {
						   ?>
						    <td>
							    <i class="fa fa-times-circle text-danger" style="font-size:28px;"></i>&nbsp;
							    <i class="fa fa-times-circle text-danger" style="font-size:28px;"></i>&nbsp;							   							  
							</td>
						   <?php
						 }
						  else if($row1["room_type"]=="Three Seater")
						 {
						   ?>
						    <td>
							   <i class="fa fa-times-circle text-danger" style="font-size:28px;"></i>&nbsp;							   
							   <i class="fa fa-times-circle text-danger" style="font-size:28px;"></i>&nbsp;							   
							   <i class="fa fa-check-circle text-success" style="font-size:28px;"></i>&nbsp;		  
							</td>
						   <?php
						 }
					 }			
                      
                      if($row2["total"]==3)
					 {
						 if($row1["room_type"]=="Single")
						 {
						   ?>
						    <td>
							  <i class="fa fa-times-circle text-danger" style="font-size:28px;"></i>&nbsp;
							</td>
						   <?php
						 }
						 else if($row1["room_type"]=="Two Seater")
						 {
						   ?>
						    <td>
							    <i class="fa fa-times-circle text-danger" style="font-size:28px;"></i>&nbsp;						  
							    <i class="fa fa-times-circle text-danger" style="font-size:28px;"></i>&nbsp;						  
							</td>
						   <?php
						 }
						  else if($row1["room_type"]=="Three Seater")
						 {
						   ?>
						    <td>
							    <i class="fa fa-times-circle text-danger" style="font-size:28px;"></i>&nbsp;
							    <i class="fa fa-times-circle text-danger" style="font-size:28px;"></i>&nbsp;
							    <i class="fa fa-times-circle text-danger" style="font-size:28px;"></i>&nbsp;
							</td>
						   <?php
						 }
					 }							
				 }					 
			  ?>
		  </tr>
		  <?php
		  $sr++;
	  }
	  
  }
   
?>