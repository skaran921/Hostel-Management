<?php
session_start();
if(isset($_SESSION["admin_id"]))
{
}
else
{
	header("Location:index.php");
}
include 'db.php';
		   $sql="SELECT * FROM session";
		   $result=$conn->query($sql);
		   if($row=$result->fetch_assoc())
		   {
			 $_SESSION["current_session"]=$row["session"];	  
		   }	
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
    <meta name="description" content="Hostel Management Application In Php">
    <meta name="keywords" content="skaran921,karan soni,Hostel Management">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link rel="icon" href="logo/logo.png" type="img/png"> 
   <script src="js/time.js"></script>
      <style>
	      #bottom{position:fixed;bottom:0;opacity:.7px;}
		  #bottom a{text-decoration:none};
	  </style>
    <title>Dashboard - Hostel Management</title>
	
	 <!-------------------------Font Style ----------------------------->
	                        <?php
                               include 'db.php';							 
                               $sql="SELECT * FROM font_style WHERE id=1";
                               $result=$conn->query($sql);
                               if($row=$result->fetch_assoc())
							   {
								   ?>
								     <style>
									    body{font-family:<?php echo $row['font_style'];?>}
									 </style>
								   <?php
							   }
							?>
	 <!-------------------------Font Style ----------------------------->
	
  </head>
  <body>
       <?php
	       include 'header.php';
	   ?>
	   <br>
	   <br>
	   <br>
    <div class="container" style="margin-top:2px;margin-bottom:2px;">
     <div class="row"><!--------Row Start --------->
	
       <div class="col-sm-3 border" style="padding:10px">	 
	      <b><center><i class="fa fa-user-circle text-success"></i> Current Admin:
		  <div class="text-danger">
		      Welcome <?php echo current_admin_name();?><br><?php echo current_admin_user_name();?>
	      </div></center></b>	   	 
	   </div>
	 
      <div class="col-sm-3 border" style="padding:10px">	 
	      <b><center><i class="fa fa-users"></i> Total Admin: <div class="text-success"><?php echo total_admin();?></div></center></b>
	  <div class="progress" style="width:">
	     <div class="progress-bar progress-bar-striped bg-success" style="width:<?php echo total_admin()*10; ?>%">
		 </div>		 
	  </div>
      </div>
	  
	   <div class="col-sm-3 border" style="padding:10px">	 
	      <b><center><i class="fa fa-building"></i> Total Room's: <div class="text-success"><?php echo total_room();?></div></center></b>
	    <div class="progress" style="width:">
		
	     <div class="progress-bar progress-bar-striped bg-success" style="width:<?php echo round((ground_floor_total_room()/total_room())*100); ?>%">
		    Ground: <?php echo ground_floor_total_room();?>
		 </div>		

		  <div class="progress-bar progress-bar-striped bg-primary" style="width:<?php echo round((first_floor_total_room()/total_room())*100); ?>%">
		    1st: <?php echo first_floor_total_room();?>
		 </div>		
		 
		 <div class="progress-bar progress-bar-striped bg-danger" style="width:<?php echo round((secound_floor_total_room()/total_room())*100); ?>%">
		    2nd: <?php echo secound_floor_total_room();?>
		 </div>	
		 
	    </div>
      </div>
	  
	   <div class="col-sm-3 border" style="padding:10px">	 
	      <b><center><i class="fa fa-building"></i> Free Room's: <div class="text-success"><?php echo total_room_from_room_table()-totally_free_room();?></div></center></b>
	    <div class="progress" style="width:">
	     <div class="progress-bar progress-bar-striped bg-info" style="width:<?php echo round((totally_free_room()/total_room_from_room_table())*100); ?>%">
		 </div>		 
	    </div>
      </div>
	  
	   <div class="col-sm-3 border" style="padding:10px">	 
	      <b><center><i class="fa fa-calendar"></i> Current Session: <div class="text-info"><i class="fa fa-certificate text-warning"></i> <?php echo $_SESSION["current_session"];?></div></center></b>
	            <center>  <div id="time"></div></center>
      </div>
	  
	  <div class="col-sm-3 border" style="padding:10px">	 
	      <b><center><i class="fa fa-user-o text-danger"></i> Total Student's: <div class="text-info"><i class="fa fa-info-circle text-primary"></i> <?php echo total_student();?></div></center></b>
      </div>
	  
	  <div class="col-sm-3 border" style="padding:10px">	 
	      <b><center><i class="fa fa-warning text-danger"></i> Warning: <div class="text-info"> <?php echo warning();?></div></center></b>
      </div>
	  <div class="col-sm-3 border" style="padding:10px">	 
	      <b><center><i class="fa fa-info-circle text-primary"></i> Notification: <div class="text-info"> <div style="overflow:scroll;overflow-x:hidden;max-height:50px"> <?php echo notification();?></div></div></center></b>
      </div>
	  
	  <div class="col-sm-3 border" style="padding:10px">	 
	      <b><center><i class="fa fa-info-circle"></i> Room Type: <div class="text-success"> <?php echo total_room_from_room_table();?></div></center></b>
	    <div class="progress" style="">
		
	     <div class="progress-bar progress-bar-striped bg-success" style="width:<?php echo round((total_single_room()/total_room_from_room_table())*100); ?>%">
		  <i class="fa fa-single"></i> <?php echo total_single_room();?>
		 </div>		

		  <div class="progress-bar progress-bar-striped bg-primary" style="width:<?php echo round((total_two_seater_room()/total_room_from_room_table())*100); ?>%">
		    Two Seater: <?php echo total_two_seater_room();?>
		 </div>		
		 
		 <div class="progress-bar progress-bar-striped bg-danger" style="width:<?php echo round((total_three_seater_room()/total_room_from_room_table())*100); ?>%">
		  <?php echo total_three_seater_room();?>
		 </div>	
		 
	    </div>	 
	  </div>     
	  
	  <div class="col-sm-5 border" style="padding:10px">	 
	      <b><center><i class="fa fa-info-circle"></i> Total Room Added: <div class="text-success"> <?php echo total_room_from_room_table();?></div></center></b>
	    <div class="progress" style="">
		
	     <div class="progress-bar progress-bar-striped bg-success" style="width:<?php echo round((total_room_in_ground_floor()/total_room_from_room_table())*100); ?>%">
		    Ground: <?php echo total_room_in_ground_floor();?>
		 </div>		

		  <div class="progress-bar progress-bar-striped bg-primary" style="width:<?php echo round((total_room_in_first_floor()/total_room_from_room_table())*100); ?>%">
		    1st Floor: <?php echo total_room_in_first_floor();?>
		 </div>		
		 
		 <div class="progress-bar progress-bar-striped bg-danger" style="width:<?php echo round((total_room_in_secound_floor()/total_room_from_room_table())*100); ?>%">
		  2nd Floor: <?php echo total_room_in_secound_floor();?>
		 </div>	
		 
	    </div>	 
	  </div>     
	  
	   <div class="col-sm-4 border" style="padding:10px">	 
	      <b class="text-dark"><center><i class="fa fa-building"></i> Room Not Added In <i class="fa fa-database"></i>:
               		  <div class="text-danger"><i class="fa fa-warning"></i> <?php echo total_room()-total_room_from_room_table();?></div></center></b>
	    <div class="progress" style="">
		
	     <div class="progress-bar progress-bar-striped bg-success" style="width:<?php echo round((ground_floor_total_room()-total_room_in_ground_floor())/(total_room()-total_room_from_room_table())*100); ?>%">
		    Ground: <?php echo ground_floor_total_room()-total_room_in_ground_floor();?>
		 </div>		

		  <div class="progress-bar progress-bar-striped bg-primary" style="width:<?php echo round((ground_floor_total_room()-total_room_in_ground_floor())/(total_room()-total_room_from_room_table())*100); ?>%">
		    1st: <?php echo first_floor_total_room()-total_room_in_first_floor();?>
		 </div>		
		 
		 <div class="progress-bar progress-bar-striped bg-danger" style="width:<?php echo round((secound_floor_total_room()-total_room_in_secound_floor())/(total_room()-total_room_from_room_table())*100); ?>%">
		  2nd: <?php echo secound_floor_total_room()-total_room_in_secound_floor();?>
		 </div>			 
	    </div>	 
	  </div>     
	  
	    <div class="col-sm-6 border" style="padding:10px">	 
	      <b><center><i class="fa fa-bed"></i> Total Furniture In Room: <div class="text-success"> <?php echo total_furniture();?></div></center></b>
	    <div class="progress" style="">
		
	     <div class="progress-bar progress-bar-striped bg-success" style="width:<?php echo round((total_chair()/total_furniture())*100); ?>%">
		    Chair: <?php echo total_chair();?>
		 </div>		

		  <div class="progress-bar progress-bar-striped bg-primary" style="width:<?php echo round((total_table()/total_furniture())*100); ?>%">
		    Table: <?php echo total_table();?>
		 </div>		
		 
		 <div class="progress-bar progress-bar-striped bg-danger" style="width:<?php echo round((total_bed()/total_furniture())*100); ?>%">
		  Bed: <?php echo total_bed();?>
		 </div>	
		 
		 <div class="progress-bar progress-bar-striped bg-dark" style="width:<?php echo round((total_bed()/total_furniture())*100); ?>%">
		  Almirah: <?php echo total_almirah();?>
		 </div>	
		 
	    </div>	 
	  </div>   
	  
	  <div class="col-sm-3 border" style="padding:10px">	 
	      <b><center><i class="fa fa-key text-warning"></i> Last Password Changed On: <div class="text-warning">
		             <i class="fa fa-info-circle text-warning"></i> <?php echo date("d-m-Y h:i:s A",strtotime(password_changed_on()));?></div></center></b>
      </div>
	  
	    <div class="col-sm-3 border" style="padding:10px">	 
	      <b><center><i class="fa fa-info-circle text-info"></i> Last Room issue On: <div class="text-danger">
		             <i class="fa fa-info-circle text-danger"></i> <?php echo date("d-m-Y h:i:s A",strtotime(last_room_issue_on()));?></div></center></b>
      </div>
	  
	  
	  
	  <div class="col-sm-3 border" style="padding:10px">	 
	      <b><center><i class="fa fa-cutlery"></i> Mess Attendance(Breakfast): <div class="text-success"><i class="fa fa-star text-warning"></i> <?php echo mess_attendance_in_breakfast();?></div></center></b>
	            <center>  <div id="time"></div></center>
      </div>
	  
	   <div class="col-sm-3 border" style="padding:10px">	 
	      <b><center><i class="fa fa-cutlery"></i> Mess Attendance(Lunch): <div class="text-success"><i class="fa fa-star text-warning"></i> <?php echo mess_attendance_in_lunch();?></div></center></b>
	            <center>  <div id="time"></div></center>
      </div>
	  
	    <div class="col-sm-3 border" style="padding:10px">	 
	      <b><center><i class="fa fa-cutlery"></i> Mess Attendance(Dinner): <div class="text-success"><i class="fa fa-star text-warning"></i> <?php echo mess_attendance_in_dinner();?></div></center></b>
	            <center>  <div id="time"></div></center>
      </div>
	 
	 <div class="col-sm-3 border" style="padding:10px">	 
	      <b><center><i class="fa fa-star text-danger"></i> Today Guest Entry: <div class="text-info"><i class="fa fa-info-circle text-primary"></i> <?php echo total_in_entry();?></div></center></b>
      </div>   
	  
	 </div><!--------Row end ----------->
    </div>	 
	   <?php
	       include 'footer.php';
	   ?>
	  
<div id="bottom">
  <a href="super user.php" title="Super User">
   <button type="button" class="btn card"><i class="fa fa-user-secret"></i></button>    
  </a>
</div>
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="alertify/js/alertify.js"></script>
	<!-- Add icon library -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </body>
</html>

<?php
     function total_admin()
	 {
		 $totaladmin=0;
		 include 'db.php';
		 $sql="SELECT * FROM admin";
		 $result=$conn->query($sql);
		 while($row=$result->fetch_assoc())
		 {
			 $totaladmin++;
		 }
		 echo $totaladmin;
	 }
	 
	 function current_admin_name()
	 {
		 $admin_id=$_SESSION['admin_id'];
		 include 'db.php';
		 $sql="SELECT name FROM admin WHERE id='$admin_id'";
		 $result=$conn->query($sql);
		 if($row=$result->fetch_assoc())
		 {
	         echo $row['name'];
		 }
	 }
	 
	 function current_admin_user_name()
	 {
		 $admin_id=$_SESSION['admin_id'];
		 include 'db.php';
		 $sql="SELECT email FROM admin WHERE id='$admin_id'";
		 $result=$conn->query($sql);
		 if($row=$result->fetch_assoc())
		 {
	         echo $row['email'];
		 }
	 }
	 
	 function total_room()
	 {
		 $total_room=0;
		 include 'db.php';
		 $sql="SELECT total_room FROM total_room";
		 $result=$conn->query($sql);
		 while($row=$result->fetch_assoc())
		 {
	         $total_room=$total_room+$row["total_room"];
		 }
		 return $total_room;
	 }
	 
	 function ground_floor_total_room()
	 {
		 $total_room=0;
		 include 'db.php';
		 $sql="SELECT total_room FROM total_room WHERE floor='Ground'";
		 $result=$conn->query($sql);
		 while($row=$result->fetch_assoc())
		 {
	         $total_room=$total_room+$row["total_room"];
		 }
		 return $total_room;
	 }
	 
	 function first_floor_total_room()
	 {
		 $total_room=0;
		 include 'db.php';
		 $sql="SELECT total_room FROM total_room WHERE floor='1st'";
		 $result=$conn->query($sql);
		 while($row=$result->fetch_assoc())
		 {
	         $total_room=$total_room+$row["total_room"];
		 }
		 return $total_room;
	 }
	 
	 function secound_floor_total_room()
	 {
		 $total_room=0;
		 include 'db.php';
		 $sql="SELECT total_room FROM total_room WHERE floor='2nd'";
		 $result=$conn->query($sql);
		 while($row=$result->fetch_assoc())
		 {
	         $total_room=$total_room+$row["total_room"];
		 }
		 return $total_room;
	 }
	
     function totally_free_room()
	 {		
		 $current_session=$_SESSION["current_session"];
		 include 'db.php';		 
		 $total_free_room=0;
          $sql="SELECT COUNT(room_id) AS total FROM issue_room WHERE session='$current_session'";
          $result=$conn->query($sql);		  
			 if($row=$result->fetch_assoc())
			 {
				 $total_free_room=$row["total"];
			 }	 
		 return $total_free_room;
	 }	

     function total_student()
	 {		
		 $current_session=$_SESSION["current_session"];
		 include 'db.php';	         
		 $sql="SELECT count(*) as total FROM student WHERE session='$current_session'"; 
		 $result=$conn->query($sql);
           if($row=$result->fetch_assoc())
		   {
			  $total_student=$row["total"]; 
		   }		 
		 return $total_student;
	 }	

     function total_single_room()
	 {
		 include 'db.php';	         
		 $sql="SELECT count(*) as total FROM room WHERE room_type='Single'"; 
		 $result=$conn->query($sql);
           if($row=$result->fetch_assoc())
		   {
			  $total_single_room=$row["total"]; 
		   }		 
		   return $total_single_room;
	 }
	 
     function total_two_seater_room()
	 {
		 include 'db.php';	         
		 $sql="SELECT count(*) as total FROM room WHERE room_type='Two Seater'"; 
		 $result=$conn->query($sql);
           if($row=$result->fetch_assoc())
		   {
			  $total_single_room=$row["total"]; 
		   }		 
		   return $total_single_room;
	 }	

     function total_three_seater_room()
	 {
		 include 'db.php';	         
		 $sql="SELECT count(*) as total FROM room WHERE room_type='Three Seater'"; 
		 $result=$conn->query($sql);
           if($row=$result->fetch_assoc())
		   {
			  $total_single_room=$row["total"]; 
		   }		 
		   return $total_single_room;
	 }	

	 function total_room_from_room_table()
	 {
		 include 'db.php';	                	 
		 $sql="SELECT count(*) as total FROM room"; 
		 $result=$conn->query($sql);
           if($row=$result->fetch_assoc())
		   {
			  $total_room=$row["total"]; 
		   }		 
		   return $total_room;
	 }	
	 
	 function total_room_in_ground_floor()
	 {
		 include 'db.php';	                	 
		 $sql="SELECT count(*) as total FROM room WHERE floor='Ground'"; 
		 $result=$conn->query($sql);
           if($row=$result->fetch_assoc())
		   {
			  $total_room=$row["total"]; 
		   }		 
		   return $total_room;
	 }	
	 
	 function total_room_in_first_floor()
	 {
		 include 'db.php';	                	 
		 $sql="SELECT count(*) as total FROM room WHERE floor='1st'"; 
		 $result=$conn->query($sql);
           if($row=$result->fetch_assoc())
		   {
			  $total_room=$row["total"]; 
		   }		 
		   return $total_room;
	 }	
	 
	  function total_room_in_secound_floor()
	 {
		 include 'db.php';	                	 
		 $sql="SELECT count(*) as total FROM room WHERE floor='2nd'"; 
		 $result=$conn->query($sql);
           if($row=$result->fetch_assoc())
		   {
			  $total_room=$row["total"]; 
		   }		 
		   return $total_room;
	 }	
	 
	 function warning()
	 {
		$current_session=$_SESSION["current_session"];
	 	$year=date("Y");		
	 	$month=date("m");		
		if($month<=5)
		{
			echo $year11=$year-1;
			echo $year1=date('y', strtotime($year. ' + 6 month'));
			 $compare_session=$year11."-".$year1;
		}
		else
		{
	 	   $year1=date('y', strtotime($year. ' + 1 years'));
		    $compare_session=$year."-".$year1;
		}      		
		if($compare_session==$current_session)
		{
			?>
			<b class="text-success"><i class="fa fa-check-circle"style="font-size:20px;"></i> No Warning Found</b>
			<?php 
		}
		else
		{
			?>
			<b class="text-danger"><i class="fa fa-warning"style="font-size:20px;"></i> Not Selected Current Session</b>
			<script>
			var msg="<b class='text-danger'><i class='fa fa-warning' style='font-size:20px;'></i> Not Selected Current Session</b>";			  
			</script>
			<?php 
		}
	 }
	 
	 
	 function total_furniture()
	 {
		 $total_furniture=total_chair()+total_table()+total_bed()+total_almirah();
		 return $total_furniture;
	 }	 
	 
	 function total_chair()
	 {
		 include 'db.php';
		 $sql="SELECT SUM(chair) as total FROM furniture";
		 $result=$conn->query($sql);
		 if($row=$result->fetch_assoc())
		 {
			$total_room=$row["total"];  
		 }
		 return $total_room;
	 }	 
	 
	 function total_table()
	 {
		 include 'db.php';
		 $sql="SELECT SUM(tables) as total FROM furniture";
		 $result=$conn->query($sql);
		 if($row=$result->fetch_assoc())
		 {
			$total_room=$row["total"];  
		 }
		 return $total_room;
	 }	 
    
	function total_bed()
	 {
		 include 'db.php';
		 $sql="SELECT SUM(bed) as total FROM furniture";
		 $result=$conn->query($sql);
		 if($row=$result->fetch_assoc())
		 {
			$total_room=$row["total"];  
		 }
		 return $total_room;
	 }

     function total_almirah()
	 {
		 include 'db.php';
		 $sql="SELECT SUM(chair) as total FROM furniture";
		 $result=$conn->query($sql);
		 if($row=$result->fetch_assoc())
		 {
			$total_room=$row["total"];  
		 }
		 return $total_room;
	 }
	 
	 function password_changed_on()
	 {
		 include 'db.php';
		 $admin_id=$_SESSION["admin_id"];
		 $sql="SELECT u_id FROM admin WHERE id='$admin_id'";
		 $result=$conn->query($sql);
		 if($row=$result->fetch_assoc())
		 {
			$u_id=$row["u_id"];  
		 }
		 return $u_id;
	 }
	 
	 function last_room_issue_on()
	 {
		 include 'db.php';
		 $admin_id=$_SESSION["admin_id"];
		 $sql="SELECT u_id FROM issue_room ORDER BY id DESC";
		 $result=$conn->query($sql);
		 if($row=$result->fetch_assoc())
		 {
			$u_id=$row["u_id"];  
		 }
		 return $u_id;
	 }
	 
	 function notification()
	 {
		 include 'db.php';
		 $sql1="SELECT room_no FROM room ORDER BY room_no";		
		 $result1=$conn->query($sql1);		
		 while($row1=$result1->fetch_assoc())
		 {
			 $room_no=$row1["room_no"];
			 $sql2="SELECT room_no FROM furniture WHERE room_no='$room_no' ORDER BY room_no";
			 $result2=$conn->query($sql2);
			 if($row2=$result2->fetch_assoc())
			 {				 
			 }
			 else
			 {
				 
					 ?>	
                     <i class="fa fa-info-circle text-danger"></i>					 
					 <b class="text-danger">Furniture Not Added In Room No. <?php echo $row1["room_no"]; ?><br></b>
					 <?php
			 }
                 					 
		 }
               					
	 }
	 
	 function mess_attendance_in_breakfast()
	 {
		 include 'db.php';
		 $today_date=date("d-m-Y");
		 $current_session=$_SESSION["current_session"];
		 $sql="SELECT COUNT(mess_id) AS total FROM mess_attendance WHERE date='$today_date' AND session='$current_session' AND attendance_for='Breakfast'";
		 $result=$conn->query($sql);
		 if($row=$result->fetch_assoc())
		 {
			return $row["total"];
		 }
	 }
	 
	 
	 function mess_attendance_in_lunch()
	 {
		 include 'db.php';
		 $today_date=date("d-m-Y");
		 $current_session=$_SESSION["current_session"];
		 $sql="SELECT COUNT(mess_id) AS total FROM mess_attendance WHERE date='$today_date' AND session='$current_session' AND attendance_for='Lunch'";
		 $result=$conn->query($sql);
		 if($row=$result->fetch_assoc())
		 {
			return $row["total"];
		 }
	 }
	 
	 
	 function mess_attendance_in_dinner()
	 {
		 include 'db.php';
		 $today_date=date("d-m-Y");
		 $current_session=$_SESSION["current_session"];
		 $sql="SELECT COUNT(mess_id) AS total FROM mess_attendance WHERE date='$today_date' AND session='$current_session' AND attendance_for='Dinner'";
		 $result=$conn->query($sql);
		 if($row=$result->fetch_assoc())
		 {
			return $row["total"];
		 }
	 }
	 
	 function total_in_entry()
	 {
		 include 'db.php';
		 $date=date("d-m-Y");
		 $current_session=$_SESSION["current_session"];
		 $sql="SELECT COUNT(*)AS total FROM in_entry where date='$date' AND session='$current_session'";
		 $result=$conn->query($sql);
		 if($row=$result->fetch_assoc())
		 {
			 return $row["total"];
		 }
		 
	 }
?>

