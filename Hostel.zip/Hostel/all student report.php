<?php
session_start();
if(isset($_SESSION["admin_id"]))
{
}
else
{
	header("Location:index.php");
}

           include 'db.php';
		   $sql="SELECT * FROM session";
		   $result=$conn->query($sql);
		   if($row=$result->fetch_assoc())
		   {
			 $_SESSION["current_session"]=$row["session"];	  
		   }	

?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
    <meta name="description" content="Hostel Management Application In Php">
    <meta name="keywords" content="skaran921,karan soni,Hostel Management">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link rel="icon" href="logo/logo.png" type="img/png"> 
    <title>All Student Report - Hostel Management</title>
	    <!-------------------------Font Style ----------------------------->
	                        <?php
                               include 'db.php';							 
                               $sql="SELECT * FROM font_style WHERE id=1";
                               $result=$conn->query($sql);
                               if($row=$result->fetch_assoc())
							   {
								   ?>
								     <style>
									    body{font-family:<?php echo $row['font_style'];?>}
									 </style>
								   <?php
							   }
							?>
	 <!-------------------------Font Style ----------------------------->
  </head>
  <body>
       <?php
	       include 'header.php';
	   ?>
	   <br>
	   <br>
	   <br>
               <div class="container-fluid">
			    <center>
			      <h1 class="text-primary"><i class="fa fa-user"></i> All Student Report</h1>
			       <button type="button" onclick="window.print()" class="btn btn-secoundary" title="click here for print"><i class="fa fa-print"></i> Print</button>
				</center>
			        <div class="table-responsive">
					   
					    <table class="table table-striped table-hover table-bordered">
						  <tr class="thead-dark fixed">
						      <th>Sr. No.</th>
						      <th>Name</th>
						      <th>Father Name</th>
						      <th>DOB</th>
						      <th>Address</th>
						      <th>City / Village</th>
						      <th>District</th>
						      <th>Pin-Code</th>
						      <th>Class</th>
						      <th>Roll No</th>
						      <th>Session</th>
						      <th>Mobile No</th>
						      <th>Parents Mobile No</th>
						      <th>Image</th>						      
						      <th>Mess ID</th>						      
						  </tr>
						  <?php student_detail();?>
						</table>
					</div>
			   </div>
	   <?php
	       include 'footer.php';
	   ?>
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="alertify/js/alertify.js"></script>
	<!-- Add icon library -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </body>
</html>

<?php 
function student_detail()
{
	$sr=1;
   include 'db.php';
   $current_session=$_SESSION["current_session"];
    $sql="SELECT * FROM student WHERE session='$current_session' ORDER BY session DESC";
	$result=$conn->query($sql);
	while($row=$result->fetch_assoc())
	{
       ?>
	   <tr>
	      <td class="bg-dark text-light font-weight-bold"><?php echo $sr;?></td>
	      <td class="text-success font-weight-bold"><?php echo $row['name'];?></td>
	      <td class="text-primary font-weight-bold"><?php echo $row['fname'];?></td>
	      <td class="font-weight-bold"><?php echo $row['dob'];?></td>
	      <td class="font-weight-bold"><?php echo $row['address'];?></td>
	      <td class="font-weight-bold"><?php echo $row['city'];?></td>
	      <td class="font-weight-bold"><?php echo $row['district'];?></td>
	      <td class="font-weight-bold"><?php echo $row['pin'];?></td>
	      <td class="font-weight-bold"><?php echo $row['class'];?></td>
	      <td class="font-weight-bold"><?php echo $row['class_roll_no'];?></td>
	      <td class="font-weight-bold"><?php echo $row['session'];?></td>
	      <td class="font-weight-bold"><?php echo $row['student_mobile_no'];?></td>
	      <td class="font-weight-bold"><?php echo $row['parent_mobile_no'];?></td>
	      <td class="text-danger font-weight-bold"><img src="students/images/<?php echo $row['session']."/".$row['class']."/".$row['name'].$row['fname'].$row['dob'].$row['session'].$row['image']; ?>" style="max-width:60px;max-height:70px;" class="rounded-circle img-fluid card"></td>
	      <td class="text-danger font-weight-bold"><?php echo $row['mess_id'];?></td>
		 </tr>
	   <?php
	   $sr++;
	}
}
?>

<?php
function admin_name($admin_id)
  {
	  include 'db.php';
	  $sql="SELECT name FROM admin Where id='$admin_id'";
	  $result=$conn->query($sql);
	  if($row=$result->fetch_assoc())
	  {
		  return $row['name'];	  
	  }
  }	   
?>

<style type="text/css" media="print">
@page{size:landscape;}
table{font-size:7px;}
#footer{display:none;}
</style>