<?php
session_start();
if(isset($_SESSION["admin_id"]))
{
}
else
{
	header("Location:index.php");
}
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
    <meta name="description" content="Hostel Management Application In Php">
    <meta name="keywords" content="skaran921,karan soni,Hostel Management">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link rel="icon" href="logo/logo.png" type="img/png"> 
    <title>Change Password - Hostel Management</title>
	 <!-------------------------Font Style ----------------------------->
	                        <?php
                               include 'db.php';							 
                               $sql="SELECT * FROM font_style WHERE id=1";
                               $result=$conn->query($sql);
                               if($row=$result->fetch_assoc())
							   {
								   ?>
								     <style>
									    body{font-family:<?php echo $row['font_style'];?>}
									 </style>
								   <?php
							   }
							?>
	 <!-------------------------Font Style ----------------------------->
  </head>
  <body>
       <?php
	       include 'header.php';
	   ?>
	   <br>
	   <br>
	   <br> 
	   <center>
        <div class="" style="max-width:600px">
		   <div class="card">
		       <div class="card-header bg-danger text-light">
			       <b><i class="fa fa-key"></i> Change Password</b>
			   </div>
			   
			   <div class="card-body">
			         <form action="change password.php" method="post" align="left">
					    <div class="alert alert-danger font-weight-bold" id="error"></div>
					    <div class="alert alert-success font-weight-bold" id="msg"></div>
					    <div class="form-group">
						   <label class="form-check-label"><b><i class="fa fa-unlock"></i> Old Password:<i class="fa fa-asterisk text-danger"></i></b></label>
						     <input type="password" name="old_password" id="old_password" class="form-control" placeholder="Old Password" required autofocus>
						</div>
						
						<div class="form-group">
						   <label class="form-check-label"><b><i class="fa fa-lock"></i> New Password:<i class="fa fa-asterisk text-danger"></i></b></label>
						     <input type="password" name="new_password" id="new_password" class="form-control" placeholder="New Password" required>
						</div>
						
						<div class="form-group">
						   <label class="form-check-label"><b><i class="fa fa-lock"></i> Confirm New Password:<i class="fa fa-asterisk text-danger"></i></b></label>
						     <input type="password" name="confirm_new_password" onkeyup="check()" id="confirm_new_password" class="form-control" placeholder="Confirm New Password" required>
						     <div id="check" class="alert alert-danger font-weight-bold"></div>
						    <br> <div id="check1" class="alert alert-success font-weight-bold"></div>
						</div>
						
						<div class="form-group">
						  <center>
						     <button type="submit" name="change_password" class="btn btn-danger" onclick="validate()"><i class="fa fa-check"></i> Change Password</button>
						  </center>
						</div>
					 </form>
			   </div>
 		   </div>
		</div>
	   </center>	
		<br>
	   <?php
	       include 'footer.php';
	   ?>
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="alertify/js/alertify.js"></script>
	<!-- Add icon library -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </body>
</html>

<script>
    document.getElementById("error").style.display="none";
    document.getElementById("msg").style.display="none";
	 document.getElementById("check").style.display="none";
    document.getElementById("check1").style.display="none";
  function validate()
  {
	var old_password=document.getElementById("old_password").value;  
	var new_password=document.getElementById("new_password").value;  
	var confirm_new_password=document.getElementById("confirm_new_password").value;
	var msg1="<i class='fa fa-warning'></i> Please Enter Old Password";
	var msg2="<i class='fa fa-warning'></i> Please Enter New Password";
	var msg3="<i class='fa fa-warning'></i> Please Confirm New Password";
	if(old_password=="")
	{
		document.getElementById("error").innerHTML=msg1;
		document.getElementById("error").style.display="block";
	}
	else if(new_password=="")
	{
		document.getElementById("error").innerHTML=msg2;
		document.getElementById("error").style.display="block";
	}
	else if(confirm_new_password)
	{
		document.getElementById("error").innerHTML=msg3;
		document.getElementById("error").style.display="block";
	}
  }
  
  
  function check()
  {
	 
	  var new_password=document.getElementById("new_password").value;  
	  var confirm_new_password=document.getElementById("confirm_new_password").value;
	  if(new_password==confirm_new_password)
	  {
		  document.getElementById("check1").innerHTML="<i class='fa fa-check'></i> Password Matched";
		  document.getElementById("check1").style.display="block";
		  document.getElementById("check").style.display="none";
		 
	  }
	  else
	  {
		  document.getElementById("check").innerHTML="<i class='fa fa-close'></i> Password Not Matched";
		  document.getElementById("check").style.display="block";
		  document.getElementById("check1").style.display="none";
	  }
  }
</script>

<?php 
  if(isset($_POST["change_password"]))
  {
	  $old_password=$_POST["old_password"];
	  $new_password=$_POST["new_password"];
	  $confirm_new_password=$_POST["confirm_new_password"];
	  $admin_id=$_SESSION["admin_id"];
	  include "db.php";
	  $sql="SELECT * FROM admin WHERE id='$admin_id' AND password='$old_password'";
	  $result=$conn->query($sql);
	  if($row=$result->fetch_assoc())
	  {
		  if($new_password==$confirm_new_password)
		  {
			  $sql1="UPDATE admin SET password='$new_password' WHERE id='$admin_id'";
			  $result1=$conn->query($sql1);
			    if($result1==TRUE)
				{
				 ?>
		          <script>
		           document.getElementById("msg").innerHTML="<i class='fa fa-check'></i> Password Changed!!!";
		           document.getElementById("msg").style.display="block";
		         </script>
               <?php	
				}
				else
				{
					 ?>
		          <script>
		           document.getElementById("error").innerHTML="<i class='fa fa-warning'></i> error!!! Password Not Changed!!!";
		           document.getElementById("error").style.display="block";
		         </script>
               <?php	
				}
		  }
		  else
		  {
			  ?>
		 <script>
		   document.getElementById("error").innerHTML="<i class='fa fa-warning'></i> New Password Not Matched!!!";
		   document.getElementById("error").style.display="block";
		</script>
        <?php	
		  }
	  }
	  else
	  {
		?>
		<script>
		   document.getElementById("error").innerHTML="<i class='fa fa-warning'></i> Old Password Not Matched!!!";
		   document.getElementById("error").style.display="block";
		</script>
        <?php	
	  }
  }
?>