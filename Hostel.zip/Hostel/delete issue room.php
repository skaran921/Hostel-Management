<?php
session_start();
if(isset($_SESSION["admin_id"]))
{
}
else
{
	header("Location:index.php");
}
include 'db.php';
		   $sql="SELECT * FROM session";
		   $result=$conn->query($sql);
		   if($row=$result->fetch_assoc())
		   {
			 $_SESSION["current_session"]=$row["session"];	  
		   }	
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
    <meta name="description" content="Hostel Management Application In Php">
    <meta name="keywords" content="skaran921,karan soni,Hostel Management">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link rel="icon" href="logo/logo.png" type="img/png"> 
    <title>Delete issue Room - Hostel Management</title>
	 <!-------------------------Font Style ----------------------------->
	                        <?php
                               include 'db.php';							 
                               $sql="SELECT * FROM font_style WHERE id=1";
                               $result=$conn->query($sql);
                               if($row=$result->fetch_assoc())
							   {
								   ?>
								     <style>
									    body{font-family:<?php echo $row['font_style'];?>}
									 </style>
								   <?php
							   }
							?>
	 <!-------------------------Font Style ----------------------------->
	<style>
	   #bottom_button{position:fixed;bottom:0;display:inline;text-decoration:none;opacity:.6;}
	   #bottom_button:hover{opacity:.9;}
	   #bottom_button a{text-decoration:none;}
	</style>
	  </head>
  <body> 
       <?php
	       include 'header.php';
	   ?> 
	   <br>
	   <br>
	   <br>
	   
	   <div class="container">
	    <div class="card">
		 <div class="card-header" style="background-color:#654;color:#fff;">
		    <b><i class="fa fa-trash"></i> Delete issue Room</b>
		 </div>
		  <div class="card-body">
	      <div class="table-responsive">
		      <table class="table table-striped table-hover table-border">
			     <tr class="thead-dark">
				     <th>Sr.No.</th>
				     <th>Room No.</th>
				     <th>Room Type.</th>
				     <th>Floor</th>
				     <th>Name</th>
				     <th>Father Name</th>
				     <th>Class</th>
				     <th>Mobile(s)</th>
				     <th>Mess ID</th>
				     <th></th>
			     </tr>
				 <?php room_issue__detail();?>				
			  </table>
		  </div>
		 </div>
        </div>		 
	</div>
	   
 
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="alertify/js/alertify.js"></script>
	<!-- Add icon library -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </body>
<?php 
  include 'footer.php';
?>
</html>	
<script>
   function validate()
   {
	   var mess_id=document.getElementById("mess_id").value;
	   var msg1="<div class='text-danger card font-weight-bold'><center><i class='fa fa-warning' style='font-size:50px;'></i></center> Please Enter Mess ID</div>";
	   if(mess_id=="")
	   {
		   alertify.alert(msg1);
		   alertify.log(msg1);
	   }
   }
</script>
<?php
   function room_issue__detail()
   {
	   $current_session=$_SESSION["current_session"];
	   $sr=1;
	   include 'db.php';
	   $sql="SELECT * FROM issue_room WHERE session='$current_session' ORDER BY student_id ";
	   $result=$conn->query($sql);
	   while($row=$result->fetch_assoc())
	   {
		   ?>
		   <tr>
		      <td class="bg-success font-weight-bold text-light"><?php echo $sr;?></td>
              <?php echo room_detail($row["room_id"]);?>		      	     
              <?php echo student_detail($row["student_id"]);?>	
		     <td>
			  <form action="delete issue room.php" method="post">
			      <input type="hidden" id="room_id" value="<?php echo $row['id'];?>">
				  <button type="submit" name="delete" class="btn btn-danger" onclick="confirm_delete(<?php echo $row['id'];?>)"><i class="fa fa-trash"></i> Delete</button>
			  </form>
			  </td>
		   </tr>
		   <?php
		   $sr++;
	   }
   } 
  #------------------------------------
  function room_detail($room_id)
  {
	  include 'db.php';
	  $sql="SELECT * FROM room WHERE id='$room_id'";
	  $result=$conn->query($sql);
	  if($row=$result->fetch_assoc())
	  {
		  ?>
		  <td class="font-weight-bold"><?php echo $row["room_no"]?></td>
		  <td class="font-weight-bold"><?php echo $row["room_type"]?></td>
		  <td class="font-weight-bold"><?php echo $row["floor"]?></td>
		  <?php
	  }
  }
  
  function student_detail($student_id)
  {
	  include 'db.php';
	  $sql="SELECT * FROM student WHERE id='$student_id'";
	  $result=$conn->query($sql);
	  if($row=$result->fetch_assoc())
	  {
		  ?>
		  <td class="font-weight-bold"><?php echo $row["name"]?></td>
		  <td class="font-weight-bold"><?php echo $row["fname"]?></td>
		  <td class="font-weight-bold"><?php echo $row["student_mobile_no"]?></td>
		  <td class="font-weight-bold"><?php echo $row["class"]?></td>
		  <td class="font-weight-bold" style="color:dark;background-color:yellow"><?php echo $row["mess_id"]?></td>
		  <?php
	  }
  }
  
?>


<script>
  function confirm_delete(x)
  {
	  var issue_room_id=x;
	  var answer=confirm("do you really want to delete this issue room?");
	  if(answer)
	  {
		     window.open("delete issue room confirm.php?issue_room_id="+issue_room_id,"_blank");
	  }
	  else
	  {
	  }
  }
</script>