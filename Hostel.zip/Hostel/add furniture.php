<?php
session_start();
if(isset($_SESSION["admin_id"]))
{
}
else
{
	header("Location:index.php");
}
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
    <meta name="description" content="Hostel Management Application In Php">
    <meta name="keywords" content="skaran921,karan soni,Hostel Management">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link rel="icon" href="logo/logo.png" type="img/png"> 
    <title>Add Furniture - Hostel Management</title>
	 <!-------------------------Font Style ----------------------------->
	                        <?php
                               include 'db.php';							 
                               $sql="SELECT * FROM font_style WHERE id=1";
                               $result=$conn->query($sql);
                               if($row=$result->fetch_assoc())
							   {
								   ?>
								     <style>
									    body{font-family:<?php echo $row['font_style'];?>}
									 </style>
								   <?php
							   }
							?>
	 <!-------------------------Font Style ----------------------------->
  </head>
  <body>
       <?php
	       include 'header.php';
	   ?>
	   <br>
	   <br>
	   <br>
<center>
	<div class="" style="max-width:600px">
       <div class="card text-light" style="background-color:#089">
	      <div class="card-header">
		           <i class="fa fa-plus"></i> <b>Add Room Furniture</b>
		  </div>
		    <div class="card-body bg-light text-dark">
			    <div class="alert alert-danger font-weight-bold" id="error"></div>
			    <div class="alert alert-success font-weight-bold" id="msg"></div>
			     <form action="add furniture.php" method="post"  align="left">
				     <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b>Select Room No.:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <select name="room_no" id="room_no" class="form-control"  required autofocus>
							   <option></option>
							   <?php room_no(); ?>
							</select>
							</div>
					    </div>		
					 </div>
					 
					 <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b><i class="fa fa-chair text-danger"></i>Select No. of Chairs:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <select name="chair" id="chair" class="form-control" required>
							    <option>2</option>
							    <option>0</option>
							    <option>1</option>
							    <option>2</option>
							    <option>3</option>
							    <option>4</option>
							    <option>5</option>
							    <option>6</option>
							    <option>7</option>
							</select>
							</div>
					    </div>		
					 </div>
					
					 <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b>Select No. of Table:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <select name="table" id="table" class="form-control" required>							   
							    <option>2</option>
							    <option>0</option>
							    <option>1</option>
							    <option>2</option>
							    <option>3</option>
							    <option>4</option>
							    <option>5</option>
							    <option>6</option>
							    <option>7</option>
							</select>
							</div>
					    </div>		
					 </div>
					 
					 <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b> Select No. of Bed:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <select name="bed" id="bed" class="form-control" required>							   
							    <option>2</option>
							    <option>0</option>
							    <option>1</option>
							    <option>2</option>
							    <option>3</option>
							    <option>4</option>
							    <option>5</option>
							    <option>6</option>
							    <option>7</option>
							</select>
							</div>
					    </div>		
					 </div>
					 
					  <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b> Select No. of Almirah:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <select name="almirah" id="almirah" class="form-control" required>							   
							    <option>2</option>
							    <option>0</option>
							    <option>1</option>
							    <option>2</option>
							    <option>3</option>
							    <option>4</option>
							    <option>5</option>
							    <option>6</option>
							    <option>7</option>
							</select>
							</div>
					    </div>		
					 </div>
					 
					  <div class="form-group"> 
					    
						  <center>	 <button type="submit" name="add" class="btn" accesskey="A" style="background-color:indigo;color:white;" onclick="validate()" title="Click Here For Save Data"><i class="fa fa-save"></i> Add Furniture</button></center>
					 </div>
					 
                 </form>				 
			</div>
	   </div>
	</div>
</center>	
  
	   <?php
	       include 'footer.php';
	   ?>
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="alertify/js/alertify.js"></script>
	<!-- Add icon library -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </body>
</html>
<script>
document.getElementById("error").style.display="none";
document.getElementById("msg").style.display="none";
   function validate()
   {
	   var room_no=document.getElementById('room_no').value;
	   var chair=document.getElementById('chair').value;
	   var table=document.getElementById('table').value;
	   var bed=document.getElementById('bed').value;
	   var almirah=document.getElementById('almirah').value;
	   var msg1="<i class='fa fa-warning'></i> Please Select Room No.";
	   var msg2="<i class='fa fa-warning'></i> Please Select No. of Chairs";
	   var msg3="<i class='fa fa-warning'></i> Please Select No. of Table";
	   var msg4="<i class='fa fa-warning'></i> Please Select No. of Bed";
	   var msg5="<i class='fa fa-warning'></i> Please Select No. Almirah";
	   
	  
	   if(room_no=="")
	   {
		  alertify.log(msg1);   
		  document.getElementById("error").innerHTML=msg1;
		  document.getElementById("error").style.display="block";
	   }
	   else if(chair=="")
	   {
		   alertify.log(msg2);
		   document.getElementById("error").innerHTML=msg2;
		  document.getElementById("error").style.display="block";
	   }
	   else if(table=="")
	   {
		   alertify.log(msg3);
		   document.getElementById("error").innerHTML=msg3;
		  document.getElementById("error").style.display="block";
	   }
	    else if(bed=="")
	   {
		   alertify.log(msg4);
		   document.getElementById("error").innerHTML=msg4;
		  document.getElementById("error").style.display="block";
	   }
	    else if(almirah=="")
	   {
		   alertify.log(msg5);
		   document.getElementById("error").innerHTML=msg5;
		  document.getElementById("error").style.display="block";
	   }
   }
</script>

<?php
	    if(isset($_POST["add"]))
		{
		    $room_no=$_POST["room_no"];
			$chair=$_POST["chair"];
			$table=$_POST["table"];
			$bed=$_POST["bed"];
			$almirah=$_POST["almirah"];
			$admin_id=$_SESSION["admin_id"];			
			include "db.php";
			$sql1="SELECT room_no FROM furniture WHERE room_no='$room_no'";
			$result1=$conn->query($sql1);
			if($row=$result1->fetch_assoc())
			{
				?>
				  <script>
                     document.getElementById("error").innerHTML="Furniture Already Added In This Room!!!";
					 alertify.alert("<b class='alert alert-danger'>Furniture Already Added In This Room!!!</b>");
					 document.getElementById("error").style.display="block";
				  </script>
				<?php 
			}
			else
			{
                 $sql2="INSERT INTO furniture(room_no,chair,tables,bed,almirah,admin)VALUES('$room_no','$chair','$table','$bed','$almirah','$admin_id')";
                 $result2=$conn->query($sql2);
                 if($result2==TRUE)
 				 {
                            ?>
							  <script>
							    document.getElementById("msg").innerHTML="Furniture Added!!!";
								alertify.alert("<b class='alert alert-success'>Furniture Added!!!</b>");
					            document.getElementById("msg").style.display="block";										
							  </script>
                            <?php							
				 }	
                 else
				 {
					 ?>
					 <script>
					    document.getElementById("error").innerHTML="error!!! Furniture Not Added!!!";
						alertify.alert("<b class='alert alert-danger'>error!!! Furniture Not Added!!!</b>");
					    document.getElementById("error").style.display="block";
					 </script>
					 <?php
				 }					 
		         ?>
				 <?php
			}
		}
	 ?>

	 <?php 
	    function room_no()
		{
			include 'db.php';
			$sql="SELECT room_no FROM room ORDER BY room_no";
			$result=$conn->query($sql);
			while($row=$result->fetch_assoc())
			{
				echo "<option>".$row['room_no']."</option>";
			}			
		}			
     ?>