<?php
session_start();
if(isset($_SESSION["admin_id"]))
{
}
else
{
	header("Location:index.php");
}
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
    <meta name="description" content="Hostel Management Application In Php">
    <meta name="keywords" content="skaran921,karan soni,Hostel Management">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link rel="icon" href="logo/logo.png" type="img/png">  
    <title>Edit Room - Hostel Management</title>
	   <!-------------------------Font Style ----------------------------->
	                        <?php
                               include 'db.php';							 
                               $sql="SELECT * FROM font_style WHERE id=1";
                               $result=$conn->query($sql);
                               if($row=$result->fetch_assoc())
							   {
								   ?>
								     <style>
									    body{font-family:<?php echo $row['font_style'];?>}
									 </style>
								   <?php
							   }
							?>
	 <!-------------------------Font Style ----------------------------->
  </head>
  <body>
       <?php
	       include 'header.php';
	   ?>
	   <br>
	   <br>
	   <br>
	   <center>
         <div class="" style="max-width:600px">
		    <div class="card" style="background-color:cyan">
			   <div class="card-header">
			       <b><i class="fa fa-edit"></i>Edit Room</b>
			   </div>
			   <div class="card-body bg-light" align="left">
			               <div class="alert alert-warning" id="error1"></div>
						   <div class="alert alert-danger font-weight-bold" id="error"></div>
			    <div class="alert alert-success font-weight-bold" id="msg"></div>
			       <form action="edit room.php" method="post">
				      <div class="form-group form-inline">
					     <label class="form-check-label"><b>Room Number: &nbsp;</b></label>
						 <input type="number" class="form-control" name="room_no1" id="room_no1" placeholder="Room Number" required autofocus>
					  </div>
					    <div class="from-group">
						   <button type="submit" class="btn btn-success" name="go"><i class="fa fa-search"></i> Go</button>
						</div>
				   </form>
			   </div>
			</div>
		 </div>
	  </center>
   	  
 
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="alertify/js/alertify.js"></script>
	<!-- Add icon library -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </body>
</html>
<script>
document.getElementById("error1").style.display="none";
</script>
 <?php
     if(isset($_POST["go"]))
	 {
		 $room_no1=$_POST["room_no1"];
		 include 'db.php';
		 $sql="SELECT * FROM room WHERE room_no='$room_no1'";
		 $result=$conn->query($sql);
		 if($row=$result->fetch_assoc())
	     {
			 ?>
			<center> 
			 <div class="" style="max-width:600px">
       <div class="card text-light" style="background-color:skyblue">
	      <div class="card-header">
		           <i class="fa fa-edit"></i> <b>Update Room</b>
		  </div>
		    <div class="card-body bg-light text-dark">
			     <form action="edit room.php" method="post"  align="left">
				  <input type="hidden" name="room_id" id="room_id" value="<?php echo $row['id']?>">
				     <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b>Room No.:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <input type="number" name="room_no" id="room_no" value="<?php echo $row["room_no"]?>" class="form-control" placeholder="Room Number" required autofocus>
							</div>
					    </div>		
					 </div>
					 
					 <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b>Select Floor.:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <select name="floor" id="floor" class="form-control" required>
							    <option><?php echo $row["floor"]?></option>
							    <option>Ground</option>
							    <option>1st</option>
							    <option>2nd</option>
							</select>
							</div>
					    </div>		
					 </div>
					
					 <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b>Select Room Type.:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <select name="room_type" id="room_type" class="form-control" required>
							    <option><?php echo $row["room_type"]?></option>
							    <option>Single</option>
							    <option>Two Seater</option>
							    <option>Three Seater</option>
							</select>
							</div>
					    </div>		
					 </div>
					 
					  <div class="form-group"> 
					    
						  <center>	 <button type="submit" name="update" class="btn btn-primary" onclick="validate()" title="Click Here For Save Data"><i class="fa fa-save"></i> Update Room</button></center>
					 </div>
					 
                 </form>				 
			</div>
	   </div>
	</div>
</center>
			 
			 <?php
		 }
		 else
		 {
			 ?>
			    <script>
				   document.getElementById("error1").innerHTML="<b>Soory!!! Not Found!!!</b>";
				   document.getElementById("error1").style.display="block";
				   alertify.alert("<b class='alert alert-warning'>Soory!!! Not Found!!!</b>");
				</script>
			 <?php
		 }
	 }		 
  ?>
  
   <?php
	       include 'footer.php';
   ?>
   
 
<script>
document.getElementById("error").style.display="none";
document.getElementById("msg").style.display="none";
   function validate()
   {
	   var room_no=document.getElementById('room_no').value;
	   var floor=document.getElementById('floor').value;
	   var room_type=document.getElementById('room_type').value;
	   var msg1="Please Enter Room No.";
	   var msg2="Please Select Floor";
	   var msg3="Please Select Room Type";
	   if(room_no=="")
	   {
		  alertify.log(msg1);   
		  document.getElementById("error").innerHTML=msg1;
		  document.getElementById("error").style.display="block";
	   }
	   else if(floor=="")
	   {
		   alertify.log(msg2);
		   document.getElementById("error").innerHTML=msg2;
		  document.getElementById("error").style.display="block";
	   }
	   else if(room_type=="")
	   {
		   alertify.log(msg3);
		   document.getElementById("error").innerHTML=msg3;
		  document.getElementById("error").style.display="block";
	   }
   }
</script>

<?php
	    if(isset($_POST["update"]))
		{
			$room_id=$_POST["room_id"];
			$room_no=$_POST["room_no"];
			$floor=$_POST["floor"];
			$room_type=$_POST["room_type"];
			$admin_id=$_SESSION["admin_id"];
			include "db.php";
			   $sql2="UPDATE room SET room_no='$room_no',floor='$floor',room_type='$room_type',admin='$admin_id' WHERE id='$room_id'";
                 $result2=$conn->query($sql2);
                 if($result2==TRUE)
 				 {
                            ?>
							  <script>
							    document.getElementById("msg").innerHTML="Room Updated!!!";
								alertify.alert("<b class='alert alert-success'>Room Updated!!!</b>");
					            document.getElementById("msg").style.display="block";
							  </script>
                            <?php							
				 }	
                 else
				 {
					 ?>
					 <script>
					    document.getElementById("error").innerHTML="error!!! Room Not Updated!!!";
						alertify.alert("<b class='alert alert-danger'>error!!! Room Not Updated!!!</b>");
					    document.getElementById("error").style.display="block";
					 </script>
					<?php
			     }
		 }
	 ?>
 
	   