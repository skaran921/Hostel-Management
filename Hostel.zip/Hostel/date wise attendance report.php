<?php
session_start();
if(isset($_SESSION["admin_id"]))
{
}
else
{
	header("Location:index.php");
}
include 'db.php';
		   $sql="SELECT * FROM session";
		   $result=$conn->query($sql);
		   if($row=$result->fetch_assoc())
		   {
			 $_SESSION["current_session"]=$row["session"];	  
		   }	
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
    <meta name="description" content="Hostel Management Application In Php">
    <meta name="keywords" content="skaran921,karan soni,Hostel Management">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link rel="icon" href="logo/logo.png" type="img/png"> 
    <title>Today Mess Attendance Report - Hostel Management</title>
	     <!-------------------------Font Style ----------------------------->
	                        <?php
                               include 'db.php';							 
                               $sql="SELECT * FROM font_style WHERE id=1";
                               $result=$conn->query($sql);
                               if($row=$result->fetch_assoc())
							   {
								   ?>
								     <style>
									    body{font-family:<?php echo $row['font_style'];?>}
									 </style>
								   <?php
							   }
							?>
	 <!-------------------------Font Style ----------------------------->
	  </head>
  <body> 
       <?php
	       include 'header.php';
	   ?> 
	   <br>
	   <br>
	   <br>
	   <center>
	      <div class="container" style="width:600px">
		     <div class="card" align="left">
			   <div class="card-header">
			      <b></b>
			   </div>
			   <div class="card-body">
		          <form action="date wise attendance report.php" method="post">
				    <b>
					  <i class="fa fa-hand-o-right text-success"></i> Note: <i class="fa fa-check-circle text-success"></i>
					  <mark class="text-danger" style="font-size:12px"> Enter Date In Format OF DD-MM-YYYY</mark><br>
					</b>
			       <div class="form-group form-inline" style="margin-top:10px">
				       <label class="form-check-label">Date:&nbsp; </label>
					    <input type="text" name="date1" id="date1" class="form-control" placeholder="Enter Date Like DD-MM-YYYY" required autofocus>
						<button type="submit" name="go" class="btn btn-primary" onclick="validate()">Go</button>
				   </div>
			     </form>
			   </div>	 
			</div>   
		  </div><br>
		</center>  
		
		
 <?php 
   if(isset($_POST["go"]))
   {
	   $date1=$_POST["date1"];
        ?>	   
	    <div class="container-fluid">
		   <center>
		       <button type="button" onclick="window.print()" class="btn btn-default"><i class="fa fa-print"></i></button>
		   </center>
		     <div class="card">
			     <div class="card-header bg-danger text-light">
				    <b><i class="fa fa-list-alt"></i> Date Wise Mess Attendance Report For Session <span class="text-warning"><?php echo $_SESSION["current_session"];?></span></b>
				 </div>
				    <div class="card-header">
					    <div class="table-responsive">
						   <table class="table table-striped container table-bordered table-hover">
						       <tr class="thead-dark">
							     <th>Sr. No.</th>
							     <th>Date</th>
							     <th>Mess ID</th>
							     <th>Breakfast</th>
							     <th>Lunch</th>
							     <th>Dinner</th>							    
							   </tr>
							   <?php 
							       mess_attendance_detail($date1);
							   ?>
						   </table>
						</div>
					</div>
			 </div>
		</div>
	 <?php
   }
?>   
		
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="alertify/js/alertify.js"></script>
	<!-- Add icon library -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </body>
</html>


<?php
	       include 'footer.php';
?>

<?php
   function mess_attendance_detail($date1)
   {
	   include 'db.php';
	   $sr=1;
	   $current_session=$_SESSION["current_session"];
	   $today_date=$date1;
	   $prev_mess_id="";
	   $sql="SELECT * FROM mess_attendance WHERE session='$current_session' AND date='$today_date' ORDER BY mess_id,date";
	   $result=$conn->query($sql);
	   while($row=$result->fetch_assoc())	
	   {     
          $attendance_for=$row["attendance_for"];
          if($row["mess_id"]!=$prev_mess_id)
		  {			
               $date=$row["date"];	  
               $mess_id=$row["mess_id"];	  
		   ?>
		   <tr>
		      <td class="font-weight-bold"><?php echo $sr; ?></td>
		      <td class="font-weight-bold text-primary"><?php echo $row["date"]; ?></td>
		      <td class="card bg-success text-light font-weight-bold"><?php echo $row["mess_id"]; ?></td>
			  <?php	
               $sql1="SELECT attendance_for FROM mess_attendance WHERE date='$date' AND mess_id='$mess_id' AND attendance_for='Breakfast'";
               $sql2="SELECT attendance_for FROM mess_attendance WHERE date='$date' AND mess_id='$mess_id' AND attendance_for='Lunch'";
               $sql3="SELECT attendance_for FROM mess_attendance WHERE date='$date' AND mess_id='$mess_id' AND attendance_for='Dinner'";
               $result1=$conn->query($sql1);	
               $result2=$conn->query($sql2);	
               $result3=$conn->query($sql3);	
                if($row1=$result1->fetch_assoc())
				{
				    	?>
						<td align="center"><i class="fa fa-check-circle text-success"style="font-size:25px;"></i></td>
						<?php
				}	
                else
				{
					?>
					  <td align="center"><i class="fa fa-times-circle text-danger" style="font-size:25px;"></i></td>
					<?php
				}	
				
                #--------------------------------------------------
			     if($row2=$result2->fetch_assoc())
				{
				    	?>
						<td align="center"><i class="fa fa-check-circle text-success"style="font-size:25px;"></i></td>
						<?php
				}	
                else
				{
					?>
					  <td align="center"><i class="fa fa-times-circle text-danger" style="font-size:25px;"></i></td>
					<?php
				}		
				
				#--------------------------------------------------
			     if($row3=$result3->fetch_assoc())
				{
				    	?>
						<td align="center"><i class="fa fa-check-circle text-success"style="font-size:25px;"></i></td>
						<?php
				}	
                else
				{
					?>
					  <td align="center"><i class="fa fa-times-circle text-danger" style="font-size:25px;"></i></td>
					<?php
				}	
				
			   $sr++;
		  }	           		  
			  ?>
			  
		   </tr>
		   <?php
		    $prev_mess_id=$row["mess_id"];
		  
	   }
	   
   }
?>

<script>
function validate()
{
	var date1=document.getElementById("date1").value;
    var msg1="<div class='card'><b class='text-danger' style='font-size:20px;'><i class='fa fa-warning'></i> Please Enter Date</b></div>";
	if(date1=="")
	{
		alertify.closeLogOnClick(true);
		alertify.alert(msg1);
		alertify.log("<b class='text-danger' style='font-size:20px;'><i class='fa fa-warning'></i> Please Enter Date</b>");
	    document.getElementById("date1").focus();
		return false;
	}
	
	
}
</script>
