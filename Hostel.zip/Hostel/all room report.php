<?php
session_start();
if(isset($_SESSION["admin_id"]))
{
}
else
{
	header("Location:index.php");
}
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
    <meta name="description" content="Hostel Management Application In Php">
    <meta name="keywords" content="skaran921,karan soni,Hostel Management">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link rel="icon" href="logo/logo.png" type="img/png"> 
    <title>All Room Report - Hostel Management</title>
	  <!-------------------------Font Style ----------------------------->
	                        <?php
                               include 'db.php';							 
                               $sql="SELECT * FROM font_style WHERE id=1";
                               $result=$conn->query($sql);
                               if($row=$result->fetch_assoc())
							   {
								   ?>
								     <style>
									    body{font-family:<?php echo $row['font_style'];?>}
									 </style>
								   <?php
							   }
							?>
	 <!-------------------------Font Style ----------------------------->
  </head>
  <body>
       <?php
	       include 'header.php';
	   ?>
	   <br>
	   <br>
	   <br>
               <div class="container">
			    <center>
			      <h1 class="text-primary"><i class="fa fa-building"></i>All Room Report</h1>
			       <button type="button" onclick="window.print()" class="btn btn-secoundary" title="click here for print"><i class="fa fa-print"></i> Print</button>
				</center>
			        <div class="table-responsive">
					   
					    <table class="table table-striped table-hover table-bordered">
						  <tr class="thead-dark fixed">
						      <th>Sr. No.</th>
						      <th>Room No.</th>
						      <th>Floor</th>
						      <th>Room Type</th>
						      <th>Admin</th>
						      <th>Last Updated On</th>
						  </tr>
						  <?php room_detail();?>
						</table>
					</div>
			   </div>
	   <?php
	       include 'footer.php';
	   ?>
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="alertify/js/alertify.js"></script>
	<!-- Add icon library -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </body>
</html>

<?php 
function room_detail()
{
	$sr=1;
   include 'db.php';
    $sql="SELECT * FROM room ORDER BY room_no";
	$result=$conn->query($sql);
	while($row=$result->fetch_assoc())
	{
       ?>
	   <tr>
	      <td class="bg-dark text-light font-weight-bold"><?php echo $sr;?></td>
	      <td class="text-success font-weight-bold"><?php echo $row['room_no'];?></td>
	      <td class="text-primary font-weight-bold"><?php echo $row['floor'];?></td>
	      <td class="bg-warning font-weight-bold"><?php echo $row['room_type'];?></td>
	      <td class="text-danger font-weight-bold"><?php echo admin_name($row['admin']);?></td>
	      <td><?php echo "<mark class='font-weight-bold'>".date("d-m-Y h:i:s A",strtotime($row['u_id']))."</mark>";?></td>
	   </tr>
	   <?php
	   $sr++;
	}
}
?>

<?php
function admin_name($admin_id)
  {
	  include 'db.php';
	  $sql="SELECT name FROM admin Where id='$admin_id'";
	  $result=$conn->query($sql);
	  if($row=$result->fetch_assoc())
	  {
		  return $row['name'];	  
	  }
  }	   
?>