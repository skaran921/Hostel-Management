<div class="card">
  <div class="card-body bg-warning">
     <center>
	 <h6>Designed And Developed By skaran<sup>921</sup> <br> &copy;2018; All Right Reserved</h6>
	    <br>
		<h3><a href="#" title="facebook"><i class="fa fa-facebook" style="color:blue"></i></a>
		<a href="#" title="twitter"><i class="fa fa-twitter text-primary"></i></a>
		<a href="#" title="instagram"><i class="fa fa-instagram" style="color:purple"></i></a>
		<a href="#" title="google+"><i class="fa fa-google-plus text-danger"></i></a>
		<a href="#" title="vk"><i class="fa fa-vk text-primary"></i></a></h3>
	 </center>
  </div>
</div>
<link href="bootstrap-social/assets/css/font-awesome.css" rel="stylesheet">
