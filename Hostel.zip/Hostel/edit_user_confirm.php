<?php
session_start();
if(isset($_SESSION["admin_id"]) && isset($_SESSION["super_user_id"]))
{
}
else
{
	header("Location:dashboard.php");
}
?>

<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
    <meta name="description" content="Hostel Management Application In Php">
    <meta name="keywords" content="skaran921,karan soni,Hostel Management">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link rel="icon" href="logo/logo.png" type="img/png"> 	
    <title>User Management - Hostel Management</title>
	
	                        <?php
                               include 'db.php';							 
                               $sql="SELECT * FROM font_style WHERE id=1";
                               $result=$conn->query($sql);
                               if($row=$result->fetch_assoc())
							   {
								   ?>
								     <style>
									    body{font-family:<?php echo $row['font_style'];?>}
									 </style>
								   <?php
							   }
							?>

	  </head>
  <body> 
       <?php
	       include 'header.php';
	   ?> 
	   <br>
	   <br>
	   <br>
	   

  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="alertify/js/alertify.js"></script>
	<!-- Add icon library -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </body>
</html>

<?php 
if(isset($_GET["edit_user_id"]))
{
  $edit_user_id=$_GET["edit_user_id"];
  include 'db.php';
  $sql1="SELECT * FROM admin WHERE id='$edit_user_id'";
  $result1=$conn->query($sql1);
  if($row1=$result1->fetch_assoc())
  {
	   ?>
	    
		 <!-------------------------------modal----------------------->
	<center>	 
		<div style="max-width:500px" align="left">
		  <div class="container">
		        <div class="card">
			      <div class="card-header bg-primary text-light">
				        <b class="card-title">
						        <i class="fa fa-edit"></i> Edit User
						</b>						 
                  </div>
                    <div class="card-body">
					       <form action="edit_user_confirm.php" method="post">
						      <div class="form-group">
							    <input type="hidden" name="user_id" value="<?php echo $row1['id']; ?>" id="user_id"  required>
                                                <label class="form-check-label"><b>Name:</b></label>
												<input type="text" name="name" id="name" placeholder="Name OF User" class="form-control" value="<?php echo $row1['name'];?>" required>
											    <label class="form-check-label"><b>Email:</b></label>
												<input type="email" name="email" id="email" placeholder="Email eg. user@xyz.com" class="form-control" value="<?php echo $row1['email'];?>" required>
                                                 <label class="form-check-label"><b>Password:</b></label>
												<input type="password" name="password" id="password" placeholder="Password" class="form-control" value="<?php echo $row1['password'];?>" required>	  <br>                                              									
											     <button type="submit" name="save" class="btn btn-primary" onclick="validate()">Save</button>
							  </div>
						   </form>
                    </div>
                     <div class="card-footer bg-success">
					    
                     </div>					 
			   </div>
		  </div>  
		</div>  
	 </center>	
	 <?php
  }
}  
?>
					
	   <?php
 if(isset($_POST["save"]))
 {
	 include 'db.php';
	 $user_id=$_POST["user_id"];
	 $name=$_POST["name"];
	 $email=$_POST["email"];
	 $password=$_POST["password"];
	 $sql1="SELECT * FROM admin WHERE email='$email'";
	 $result1=$conn->query($sql1);
	if($row1=$result1->fetch_assoc())
	{
	   ?>
	      <script>
			     var msg="<div class='card font-weight-bold text-danger'><center><i class='fa fa-times-circle' style='font-size:50px;'></i></center>Sorry!!! account on this email already exist!!!!</div>";
			     alertify.alert(msg);
			     alertify.log(msg);
			 </script>
	   <?php
	}
    else
	{		
	 $sql="UPDATE admin SET email='$email',password='$password',name='$name' WHERE id='$user_id'";
	 $result=$conn->query($sql);
     if($result==TRUE)
     {
	    ?>
	     <script>
	      alert("User Account  Updated!!!\n Please Refresh Your Page!!!");
		  window.close();
	     </script>
	   <?php 
     }
     else 
     {
	   ?>
	     <script>
	      alert("error!!! User Account Not Updated!!!");
		  window.close();
	     </script>
	<?php
     }
	}	 
 }

?>

 <?php
	   include 'footer.php';
 ?>
 
 
 <script>
   function validate()
   {
	   var name=document.getElementById("name").value;
	   var email=document.getElementById("email").value;
	   var password=document.getElementById("password").value;	  
	   var msg1="<div class='card font-weight-bold text-danger'><center><i class='fa fa-times-circle' style='font-style:50px;'></i></center> Please Enter User Name!!!</div>";
	   var msg2="<div class='card font-weight-bold text-danger'><center><i class='fa fa-times-circle' style='font-style:50px;'></i></center> Please Enter Email ID!!!</div>";
	   var msg3="<div class='card font-weight-bold text-danger'><center><i class='fa fa-times-circle' style='font-style:50px;'></i></center> Please Enter Password!!!</div>";
	   var msg4="<div class='card font-weight-bold text-danger'><center><i class='fa fa-times-circle' style='font-style:50px;'></i></center> Please Enter Confirm Password!!!</div>";
	   var msg5="<div class='card font-weight-bold text-danger'><center><i class='fa fa-times-circle' style='font-style:50px;'></i></center> Password Not Matched!!!</div>";
	   if(name=="")
	   {
		   alertify.alert(msg1);
		   alertify.log(msg1);		   
		   return false;
	   }
	   else if(email=="")
	   {
		   alertify.alert(msg2);
		   alertify.log(msg2);
	   }
	   else if(password=="")
	   {
		   alertify.alert(msg3);
		   alertify.log(msg4);
	   }        
   }
 </script>  