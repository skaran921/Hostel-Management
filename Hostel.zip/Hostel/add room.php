<?php
session_start();
if(isset($_SESSION["admin_id"]))
{
}
else
{
	header("Location:index.php");
}
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
    <meta name="description" content="Hostel Management Application In Php">
    <meta name="keywords" content="skaran921,karan soni,Hostel Management">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link rel="icon" href="logo/logo.png" type="img/png"> 
    <title>Add Room - Hostel Management</title>
	
	 <!-------------------------Font Style ----------------------------->
	                        <?php
                               include 'db.php';							 
                               $sql="SELECT * FROM font_style WHERE id=1";
                               $result=$conn->query($sql);
                               if($row=$result->fetch_assoc())
							   {
								   ?>
								     <style>
									    body{font-family:<?php echo $row['font_style'];?>}
									 </style>
								   <?php
							   }
							?>
	 <!-------------------------Font Style ----------------------------->
	
  </head>
  <body>
       <?php
	       include 'header.php';
	   ?>
	   <br>
	   <br>
	   <br>
<center>
	<div class="" style="max-width:600px">
       <div class="card bg-primary text-light">
	      <div class="card-header">
		           <i class="fa fa-plus"></i> <b>Add New Room</b>
		  </div>
		    <div class="card-body bg-light text-dark">
			    <div class="alert alert-danger font-weight-bold" id="error"></div>
			    <div class="alert alert-success font-weight-bold" id="msg"></div>
			     <form action="add room.php" method="post"  align="left">
				     <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b>Room No.:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <input type="number" name="room_no" id="room_no" class="form-control" placeholder="Room Number" required autofocus>
							</div>
					    </div>		
					 </div>
					 
					 <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b>Select Floor.:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <select name="floor" id="floor" class="form-control" required>
							    <option>
								    <?php if(isset($_SESSION["floor"])){echo $_SESSION["floor"];}else{}?>
								</option>
							    <option>Ground</option>
							    <option>1st</option>
							    <option>2nd</option>
							</select>
							</div>
					    </div>		
					 </div>
					
					 <div class="form-group"> 
					    <div class="row">
						  <div class="col-sm-4">
					        <label class="form-check-label"><b>Select Room Type.:<i class="fa fa-asterisk text-danger"></i></b>
						  </div>
                          	<div class="col-sm-8">	 				  
						    <select name="room_type" id="room_type" class="form-control" required>
							    <option>
								   <?php if(isset($_SESSION["room_type"])){echo $_SESSION["room_type"];}else{}?>
								</option>
							    <option>Single</option>
							    <option>Two Seater</option>
							    <option>Three Seater</option>
							</select>
							</div>
					    </div>		
					 </div>
					 
					  <div class="form-group"> 
					    
						  <center>	 <button type="submit" name="add" class="btn btn-success" onclick="validate()" title="Click Here For Save Data"><i class="fa fa-save"></i> Add Room</button></center>
					 </div>
					 
                 </form>				 
			</div>
	   </div>
	</div>
</center>	
  
	   <?php
	       include 'footer.php';
	   ?>
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="alertify/js/alertify.js"></script>
	<!-- Add icon library -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </body>
</html>
<script>
document.getElementById("error").style.display="none";
document.getElementById("msg").style.display="none";
   function validate()
   {
	   var room_no=document.getElementById('room_no').value;
	   var floor=document.getElementById('floor').value;
	   var room_type=document.getElementById('room_type').value;
	   var msg1="Please Enter Room No.";
	   var msg2="Please Select Floor";
	   var msg3="Please Select Room Type";
	   if(room_no=="")
	   {
		  alertify.log(msg1);   
		  document.getElementById("error").innerHTML=msg1;
		  document.getElementById("error").style.display="block";
	   }
	   else if(floor=="")
	   {
		   alertify.log(msg2);
		   document.getElementById("error").innerHTML=msg2;
		  document.getElementById("error").style.display="block";
	   }
	   else if(room_type=="")
	   {
		   alertify.log(msg3);
		   document.getElementById("error").innerHTML=msg3;
		  document.getElementById("error").style.display="block";
	   }
   }
</script>

<?php
	    if(isset($_POST["add"]))
		{
			$room_no=$_POST["room_no"];
			$floor=$_POST["floor"];
			$room_type=$_POST["room_type"];
			$admin_id=$_SESSION["admin_id"];
			$_SESSION["room_type"]=$room_type;
			$_SESSION["floor"]=$floor;
			include "db.php";
			$sql1="SELECT * FROM room WHERE room_no='$room_no'";
			$result1=$conn->query($sql1);
			if($row=$result1->fetch_assoc())
			{
				?>
				  <script>
                     document.getElementById("error").innerHTML="Room Already Exist";
					 alertify.alert("<b class='alert alert-danger'>Room Already Exist!!!</b>");
					 document.getElementById("error").style.display="block";
				  </script>
				<?php 
			}
			else
			{
                 $sql2="INSERT INTO room(room_no,floor,room_type,admin)VALUES('$room_no','$floor','$room_type','$admin_id')";
                 $result2=$conn->query($sql2);
                 if($result2==TRUE)
 				 {
                            ?>
							  <script>
							    document.getElementById("msg").innerHTML="Room Added!!!";
								alertify.alert("<b class='alert alert-success'>Room Added!!!</b>");
					            document.getElementById("msg").style.display="block";										
							  </script>
                            <?php							
				 }	
                 else
				 {
					 ?>
					 <script>
					    document.getElementById("error").innerHTML="error!!! Room Not Added!!!";
						alertify.alert("<b class='alert alert-danger'>error!!! Room Not Added!!!</b>");
					    document.getElementById("error").style.display="block";
					 </script>
					 <?php
				 }					 
		         ?>
				 <?php
			}
		}
	 ?>
