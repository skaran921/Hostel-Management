<?php
session_start();
if(isset($_SESSION["admin_id"]))
{
}
else
{
	header("Location:index.php");
}
include 'db.php';
		   $sql="SELECT * FROM session";
		   $result=$conn->query($sql);
		   if($row=$result->fetch_assoc())
		   {
			 $_SESSION["current_session"]=$row["session"];	  
		   }	
?>
<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
    <meta name="description" content="Hostel Management Application In Php">
    <meta name="keywords" content="skaran921,karan soni,Hostel Management">
    <meta name="author" content="skaran921,Karan Soni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="alertify/css/alertify.css">
    <link rel="icon" href="" type="img"> 

    <title>Guest Entry Report - Hostel Management</title>
	
	<style>
	   #bottom_button{position:fixed;bottom:0;display:inline;text-decoration:none;opacity:.6;}
	   #bottom_button:hover{opacity:.9;}
	   #bottom_button a{text-decoration:none;}
	</style>
	  </head>
  <body> 
       <?php
	       include 'header.php';
	   ?> 
	   <br>
	   <br>
	   <br>
	   <div class="container">
	        <div class="card">
			    <div class="card-header" style="background-color:#105650;color:white;" id="top">
				   <b class=""><i class="fa fa-list-alt"></i> Guest Entry Report <span class="bg-info text-light" style="padding:7px;">Session: <?php echo $_SESSION["current_session"]; ?></span></b>
				</div>
				<div class="card-body">
				   <center>
				    <div class="" style="margin-bottom:7px;width:300px;">
					   <div class="row">
					     <div class="col-sm-2">
				            <button type="button" name="print" onclick="window.print()" class="btn btn-default card"><i class="fa fa-print"></i></button>
						 </div>
						 <div class="col-sm-2">
				          <a href="#bottom"><button type="button" name="go down" class="btn btn-default card"><i class="fa fa-arrow-down"></i></button></a>
					     </div>
					   </div>
					</div>   
				   </center>
	              <div class="table-responsive">
				      <table class="table table-striped table-bordered">
					      <tr class="thead-dark">
						     <th>Sr. No.</th>
						     <th>in Date</th>
						     <th>Name</th>
						     <th>Room No.</th>
						     <th>Mess ID</th>
						     <th>In Time</th>
						     <th>Status</th>
						     <th>Out Date</th>
						     <th>Out Time</th>
						  </tr>
						   <?php entry_detail();?>
					  </table>
				  </div>
				</div>
            </div>				
	   </div>
	       
	 <div id="bottom"></div> 

 <?php
	       include 'footer.php';
 ?> 
 
				    <div class="" style="margin-bottom:7px;width:300px;" id="bottom_button">
					   <div class="row">
					     <div class="col-sm-2">
				            <button type="button" name="print" onclick="window.print()" class="btn btn-default card"><i class="fa fa-print"></i></button>
						 </div>
						 <div class="col-sm-2">
				          <a href="#top"><button type="button" name="go top" class="btn btn-default card"><i class="fa fa-arrow-up"></i></button></a>
					     </div>
					   </div>
					</div>   

  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="alertify/js/alertify.js"></script>
	<!-- Add icon library -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </body>
</html>

<?php
   function entry_detail()
   {
	   include 'db.php';
	   $sr=1;
	   $current_session=$_SESSION["current_session"];
	   $sql1="SELECT * FROM in_entry WHERE session='$current_session' ORDER BY u_id DESC";	  
	   $result1=$conn->query($sql1);
	   while($row1=$result1->fetch_assoc())
	   {
		   $checked_in_id=$row1["id"];
		  ?>
		     <tr>
			   <td class="bg-light font-weight-bold"><?php echo $sr; ?></td>
			   <td class="bg-primary text-light font-weight-bold"><?php echo $row1["date"];?></td>
			   <td class="font-weight-bold"><?php echo $row1["name"];?></td>
			   <td class="font-weight-bold"><?php echo $row1["room_no"];?></td>
			   <td class="font-weight-bold"><?php echo $row1["mess_id"];?></td>
			   <td class="bg-success text-light font-weight-bold"><?php echo date("h:i:s A",strtotime($row1["u_id"]));?></td>
			   <?php
			         $sql2="SELECT * FROM out_entry WHERE checked_in_id='$checked_in_id'";
					 $result2=$conn->query($sql2);
					 
					 if($row2=$result2->fetch_assoc())
					 {
						 ?>
						 <td class="font-weight-bold text-success" style="font-size:30px;" align="center"><i class="fa fa-check-circle"></i></td>
						  <td class="font-weight-bold text-danger"><?php echo $row2["date"];?></td>
						    <td class="bg-danger text-light font-weight-bold"><?php echo date("h:i:s A",strtotime($row2["u_id"]));?></td>
						 <?php
					 }
					 else
					 {
						 ?>
						     <td class="font-weight-bold text-danger" style="font-size:30px;" align="center"><i class="fa fa-times-circle"></i></td>
							 <td align="center"><i class="fa fa-minus"></i></td>
							 <td align="center"><i class="fa fa-minus"></i></td>							
						 <?php 
					 }			
					 
					 	
				 
			   ?>
			 </tr>
		  <?php
		  $sr++;
	   }
   }	   
?>